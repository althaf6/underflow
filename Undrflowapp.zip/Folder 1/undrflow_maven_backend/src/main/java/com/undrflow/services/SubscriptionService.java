package com.undrflow.services;

import com.undrflow.models.Subscription;
import com.undrflow.models.User;
import com.undrflow.repositories.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SubscriptionService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;
    
    @Autowired
    private UserService userService;
    
    @Value("${app.subscription.free.contacts-limit}")
    private Integer freeContactsLimit;
    
    @Value("${app.subscription.pro.contacts-limit}")
    private Integer proContactsLimit;
    
    @Value("${app.subscription.premium.contacts-limit}")
    private Integer premiumContactsLimit;
    
    public Subscription createFreeSubscription(String userId) {
        User user = userService.getUserById(userId);
        
        Subscription subscription = Subscription.builder()
                .userId(userId)
                .plan(Subscription.PlanType.FREE)
                .status(Subscription.SubscriptionStatus.ACTIVE)
                .startDate(LocalDateTime.now())
                .currentPeriodStart(LocalDateTime.now())
                .contactsLimit(freeContactsLimit)
                .currentContactsCount(0)
                .build();
        
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription getSubscriptionByUserId(String userId) {
        return subscriptionRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Subscription not found for user: " + userId));
    }
    
    public Optional<Subscription> findSubscriptionByUserId(String userId) {
        return subscriptionRepository.findByUserId(userId);
    }
    
    public Subscription upgradeToPro(String userId) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        subscription.setPlan(Subscription.PlanType.PRO);
        subscription.setContactsLimit(proContactsLimit);
        subscription.setCurrentPeriodStart(LocalDateTime.now());
        subscription.setCurrentPeriodEnd(LocalDateTime.now().plusMonths(1));
        subscription.setStatus(Subscription.SubscriptionStatus.ACTIVE);
        
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription upgradeToPremium(String userId) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        subscription.setPlan(Subscription.PlanType.PREMIUM);
        subscription.setContactsLimit(premiumContactsLimit);
        subscription.setCurrentPeriodStart(LocalDateTime.now());
        subscription.setCurrentPeriodEnd(LocalDateTime.now().plusMonths(1));
        subscription.setStatus(Subscription.SubscriptionStatus.ACTIVE);
        
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription upgradeToEnterprise(String userId, Integer customContactsLimit) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        subscription.setPlan(Subscription.PlanType.ENTERPRISE);
        subscription.setContactsLimit(customContactsLimit);
        subscription.setCurrentPeriodStart(LocalDateTime.now());
        subscription.setCurrentPeriodEnd(LocalDateTime.now().plusMonths(1));
        subscription.setStatus(Subscription.SubscriptionStatus.ACTIVE);
        
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription cancelSubscription(String userId) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        subscription.setStatus(Subscription.SubscriptionStatus.CANCELED);
        subscription.setCanceledAt(LocalDateTime.now());
        
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription updateContactCount(String userId, Integer newCount) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        if (newCount > subscription.getContactsLimit()) {
            throw new RuntimeException("Contact limit exceeded for current subscription plan");
        }
        
        subscription.setCurrentContactsCount(newCount);
        return subscriptionRepository.save(subscription);
    }
    
    public List<Subscription> getExpiringSubscriptions() {
        LocalDateTime tomorrow = LocalDateTime.now().plusDays(1);
        return subscriptionRepository.findByEndDateBefore(tomorrow);
    }
    
    public List<Subscription> getTrialEndingSubscriptions() {
        LocalDateTime today = LocalDateTime.now();
        LocalDateTime tomorrow = today.plusDays(1);
        return subscriptionRepository.findByTrialEndsAtBetween(today, tomorrow);
    }
    
    public boolean canAddMoreContacts(String userId) {
        Subscription subscription = getSubscriptionByUserId(userId);
        return subscription.getCurrentContactsCount() < subscription.getContactsLimit();
    }
    
    public boolean isFeatureAvailable(String userId, String featureName) {
        Subscription subscription = getSubscriptionByUserId(userId);
        
        switch (featureName) {
            case "ai_features":
                return subscription.getPlan() != Subscription.PlanType.FREE;
            case "advanced_segmentation":
                return subscription.getPlan() == Subscription.PlanType.PREMIUM || 
                       subscription.getPlan() == Subscription.PlanType.ENTERPRISE;
            case "api_access":
                return subscription.getPlan() != Subscription.PlanType.FREE;
            case "remove_branding":
                return subscription.getPlan() != Subscription.PlanType.FREE;
            case "unlimited_flows":
                return subscription.getPlan() != Subscription.PlanType.FREE;
            default:
                return false;
        }
    }
}

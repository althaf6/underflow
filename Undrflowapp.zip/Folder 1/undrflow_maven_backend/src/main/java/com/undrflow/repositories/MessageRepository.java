package com.undrflow.repositories;

import com.undrflow.models.Message;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface MessageRepository extends MongoRepository<Message, String> {
    
    Page<Message> findByUserIdAndContactId(String userId, String contactId, Pageable pageable);
    
    List<Message> findByFlowId(String flowId);
    
    List<Message> findByUserIdAndStatus(String userId, Message.MessageStatus status);
    
    List<Message> findByUserIdAndSentAtBetween(String userId, LocalDateTime start, LocalDateTime end);
    
    long countByUserIdAndDirection(String userId, String direction);
    
    long countByUserIdAndChannel(String userId, String channel);
}

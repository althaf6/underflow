package com.undrflow.controllers;

import com.undrflow.models.Flow;
import com.undrflow.models.User;
import com.undrflow.services.FlowService;
import com.undrflow.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/flows")
public class FlowController {

    @Autowired
    private FlowService flowService;
    
    @Autowired
    private UserService userService;
    
    @GetMapping
    public ResponseEntity<?> getAllFlows(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        
        Page<Flow> flows = flowService.getUserFlows(user.getId(), pageable);
        
        Map<String, Object> response = new HashMap<>();
        response.put("flows", flows.getContent());
        response.put("currentPage", flows.getNumber());
        response.put("totalItems", flows.getTotalElements());
        response.put("totalPages", flows.getTotalPages());
        
        return ResponseEntity.ok(response);
    }
    
    @PostMapping
    public ResponseEntity<?> createFlow(@RequestBody Flow flow) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow createdFlow = flowService.createFlow(flow, user.getId());
        return ResponseEntity.ok(createdFlow);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> getFlowById(@PathVariable String id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow flow = flowService.getFlowById(id, user.getId());
        return ResponseEntity.ok(flow);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> updateFlow(@PathVariable String id, @RequestBody Flow flowDetails) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow updatedFlow = flowService.updateFlow(id, flowDetails, user.getId());
        return ResponseEntity.ok(updatedFlow);
    }
    
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateFlowStatus(@PathVariable String id, @RequestBody StatusUpdateRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow updatedFlow = flowService.updateFlowStatus(id, request.getStatus(), user.getId());
        return ResponseEntity.ok(updatedFlow);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteFlow(@PathVariable String id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        flowService.deleteFlow(id, user.getId());
        return ResponseEntity.ok(new MessageResponse("Flow deleted successfully"));
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getFlowsByStatus(@PathVariable String status) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow.FlowStatus flowStatus = Flow.FlowStatus.valueOf(status.toUpperCase());
        List<Flow> flows = flowService.getUserFlowsByStatus(user.getId(), flowStatus);
        return ResponseEntity.ok(flows);
    }
    
    @GetMapping("/trigger")
    public ResponseEntity<?> getFlowsByTrigger(
            @RequestParam String type,
            @RequestParam String value) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        List<Flow> flows = flowService.findActiveFlowsByTrigger(user.getId(), type, value);
        return ResponseEntity.ok(flows);
    }
    
    @PatchMapping("/{id}/statistics")
    public ResponseEntity<?> updateFlowStatistics(@PathVariable String id, @RequestBody Flow.Statistics statistics) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Flow updatedFlow = flowService.updateFlowStatistics(id, user.getId(), statistics);
        return ResponseEntity.ok(updatedFlow);
    }
    
    @GetMapping("/count")
    public ResponseEntity<?> getFlowCount() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        long count = flowService.getFlowCount(user.getId());
        
        Map<String, Long> response = new HashMap<>();
        response.put("count", count);
        
        return ResponseEntity.ok(response);
    }
    
    // Request and Response classes
    
    public static class StatusUpdateRequest {
        private Flow.FlowStatus status;
        
        public Flow.FlowStatus getStatus() {
            return status;
        }
        
        public void setStatus(Flow.FlowStatus status) {
            this.status = status;
        }
    }
    
    public static class MessageResponse {
        private String message;
        
        public MessageResponse(String message) {
            this.message = message;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
}

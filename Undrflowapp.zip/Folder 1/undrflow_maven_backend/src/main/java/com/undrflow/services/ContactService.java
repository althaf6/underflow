package com.undrflow.services;

import com.undrflow.models.Contact;
import com.undrflow.repositories.ContactRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
public class ContactService {
    
    private static final Logger logger = LoggerFactory.getLogger(ContactService.class);
    
    private final ContactRepository contactRepository;
    
    @Autowired
    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }
    
    /**
     * Get all contacts for a user with pagination
     */
    public List<Contact> getAllContactsByUserId(String userId, int page, int size) {
        logger.info("Fetching contacts for user: {}, page: {}, size: {}", userId, page, size);
        // Implementation would use repository pagination
        return contactRepository.findByUserId(userId);
    }
    
    /**
     * Get a contact by ID
     */
    public Optional<Contact> getContactById(String id) {
        logger.info("Fetching contact with ID: {}", id);
        return contactRepository.findById(id);
    }
    
    /**
     * Create a new contact
     */
    public Contact createContact(Contact contact) {
        logger.info("Creating new contact for user: {}", contact.getUserId());
        return contactRepository.save(contact);
    }
    
    /**
     * Update an existing contact
     */
    public Contact updateContact(Contact contact) {
        logger.info("Updating contact with ID: {}", contact.getId());
        return contactRepository.save(contact);
    }
    
    /**
     * Delete a contact
     */
    public void deleteContact(String id) {
        logger.info("Deleting contact with ID: {}", id);
        contactRepository.deleteById(id);
    }
    
    /**
     * Asynchronously import contacts from a file or external source
     * This method processes the import in a separate thread
     */
    @Async("taskExecutor")
    public CompletableFuture<Integer> importContactsAsync(String userId, List<Contact> contacts) {
        logger.info("Importing {} contacts for user: {}", contacts.size(), userId);
        try {
            int successCount = 0;
            
            for (Contact contact : contacts) {
                try {
                    contact.setUserId(userId);
                    contactRepository.save(contact);
                    successCount++;
                } catch (Exception e) {
                    logger.error("Error importing contact: {}", contact.getEmail(), e);
                }
            }
            
            logger.info("Successfully imported {}/{} contacts for user: {}", 
                    successCount, contacts.size(), userId);
            return CompletableFuture.completedFuture(successCount);
        } catch (Exception e) {
            logger.error("Error during contact import for user: {}", userId, e);
            return CompletableFuture.failedFuture(e);
        }
    }
    
    /**
     * Asynchronously segment contacts based on criteria
     */
    @Async("taskExecutor")
    public CompletableFuture<List<Contact>> segmentContactsAsync(String userId, String segmentCriteria) {
        logger.info("Segmenting contacts for user: {} with criteria: {}", userId, segmentCriteria);
        try {
            // This would implement the segmentation logic based on the criteria
            // For demonstration, we'll just return all contacts for the user
            List<Contact> segmentedContacts = contactRepository.findByUserId(userId);
            
            logger.info("Successfully segmented {} contacts for user: {}", 
                    segmentedContacts.size(), userId);
            return CompletableFuture.completedFuture(segmentedContacts);
        } catch (Exception e) {
            logger.error("Error segmenting contacts for user: {}", userId, e);
            return CompletableFuture.failedFuture(e);
        }
    }
    
    /**
     * Asynchronously tag multiple contacts
     */
    @Async("taskExecutor")
    public CompletableFuture<Integer> tagContactsAsync(List<String> contactIds, String tag) {
        logger.info("Tagging {} contacts with tag: {}", contactIds.size(), tag);
        try {
            int successCount = 0;
            
            for (String contactId : contactIds) {
                try {
                    Optional<Contact> contactOpt = contactRepository.findById(contactId);
                    if (contactOpt.isPresent()) {
                        Contact contact = contactOpt.get();
                        List<String> tags = contact.getTags();
                        if (!tags.contains(tag)) {
                            tags.add(tag);
                            contact.setTags(tags);
                            contactRepository.save(contact);
                        }
                        successCount++;
                    }
                } catch (Exception e) {
                    logger.error("Error tagging contact: {}", contactId, e);
                }
            }
            
            logger.info("Successfully tagged {}/{} contacts with tag: {}", 
                    successCount, contactIds.size(), tag);
            return CompletableFuture.completedFuture(successCount);
        } catch (Exception e) {
            logger.error("Error during contact tagging", e);
            return CompletableFuture.failedFuture(e);
        }
    }
}

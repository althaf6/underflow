package com.undrflow.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "messages")
public class Message {
    
    @Id
    private String id;
    
    private String userId;
    
    private String flowId;
    
    private String contactId;
    
    private String direction;
    
    private String channel;
    
    private String type;
    
    private String content;
    
    private List<Attachment> attachments;
    
    private MessageMetadata metadata;
    
    private MessageStatus status;
    
    private LocalDateTime sentAt;
    
    private LocalDateTime deliveredAt;
    
    private LocalDateTime readAt;
    
    private LocalDateTime createdAt;
    
    public enum MessageStatus {
        SENT, DELIVERED, READ, FAILED
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Attachment {
        private String type;
        private String url;
        private String name;
        private Long size;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MessageMetadata {
        private String platformMessageId;
        private String nodeId;
        private List<Button> buttons;
        
        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Button {
            private String text;
            private String value;
            private String type;
        }
    }
}

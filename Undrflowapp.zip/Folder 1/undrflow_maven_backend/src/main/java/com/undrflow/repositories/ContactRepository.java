package com.undrflow.repositories;

import com.undrflow.models.Contact;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ContactRepository extends MongoRepository<Contact, String> {
    
    Page<Contact> findByUserId(String userId, Pageable pageable);
    
    Optional<Contact> findByUserIdAndEmail(String userId, String email);
    
    Optional<Contact> findByUserIdAndPhone(String userId, String phone);
    
    List<Contact> findByUserIdAndTagsContaining(String userId, String tag);
    
    List<Contact> findByUserIdAndStatus(String userId, Contact.ContactStatus status);
    
    @Query("{'userId': ?0, 'customFields.?1': ?2}")
    List<Contact> findByUserIdAndCustomField(String userId, String fieldName, Object fieldValue);
    
    List<Contact> findByUserIdAndLastInteractionAtBefore(String userId, LocalDateTime date);
    
    long countByUserId(String userId);
    
    long countByUserIdAndStatus(String userId, Contact.ContactStatus status);
}

package com.undrflow.dto;

import com.undrflow.models.User;

/**
 * Data Transfer Object for authentication responses
 */
public class AuthResponse {
    
    private String token;
    private UserDTO user;
    
    // Default constructor
    public AuthResponse() {
    }
    
    // Constructor with fields
    public AuthResponse(String token, User user) {
        this.token = token;
        this.user = new UserDTO(user);
    }
    
    // Getters and Setters
    public String getToken() {
        return token;
    }
    
    public void setToken(String token) {
        this.token = token;
    }
    
    public UserDTO getUser() {
        return user;
    }
    
    public void setUser(UserDTO user) {
        this.user = user;
    }
}

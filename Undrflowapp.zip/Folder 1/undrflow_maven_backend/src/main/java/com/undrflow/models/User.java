package com.undrflow.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "users")
public class User {
    
    @Id
    private String id;
    
    @Indexed(unique = true)
    private String email;
    
    private String password;
    
    private String googleId;
    
    private String firstName;
    
    private String lastName;
    
    private String profilePicture;
    
    private Role role;
    
    private Status status;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    private LocalDateTime lastLoginAt;
    
    private Map<String, Object> settings;
    
    public enum Role {
        ADMIN, USER
    }
    
    public enum Status {
        ACTIVE, INACTIVE, SUSPENDED
    }
}

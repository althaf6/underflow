package com.undrflow.services;

import com.undrflow.models.Flow;
import com.undrflow.repositories.FlowRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
public class FlowService {
    
    private static final Logger logger = LoggerFactory.getLogger(FlowService.class);
    
    private final FlowRepository flowRepository;
    
    @Autowired
    public FlowService(FlowRepository flowRepository) {
        this.flowRepository = flowRepository;
    }
    
    /**
     * Get all flows for a user
     */
    public List<Flow> getAllFlowsByUserId(String userId) {
        logger.info("Fetching all flows for user: {}", userId);
        return flowRepository.findByUserId(userId);
    }
    
    /**
     * Get a flow by ID
     */
    public Optional<Flow> getFlowById(String id) {
        logger.info("Fetching flow with ID: {}", id);
        return flowRepository.findById(id);
    }
    
    /**
     * Create a new flow
     */
    public Flow createFlow(Flow flow) {
        logger.info("Creating new flow for user: {}", flow.getUserId());
        return flowRepository.save(flow);
    }
    
    /**
     * Update an existing flow
     */
    public Flow updateFlow(Flow flow) {
        logger.info("Updating flow with ID: {}", flow.getId());
        return flowRepository.save(flow);
    }
    
    /**
     * Delete a flow
     */
    public void deleteFlow(String id) {
        logger.info("Deleting flow with ID: {}", id);
        flowRepository.deleteById(id);
    }
    
    /**
     * Asynchronously execute a flow for a contact
     * This method processes the flow steps in a separate thread
     */
    @Async("taskExecutor")
    public CompletableFuture<Boolean> executeFlowAsync(String flowId, String contactId, String triggerEvent) {
        logger.info("Executing flow {} for contact {} with trigger {}", flowId, contactId, triggerEvent);
        try {
            Optional<Flow> flowOpt = flowRepository.findById(flowId);
            if (flowOpt.isEmpty()) {
                logger.error("Flow not found with ID: {}", flowId);
                return CompletableFuture.completedFuture(false);
            }
            
            Flow flow = flowOpt.get();
            if (!"ACTIVE".equals(flow.getStatus())) {
                logger.info("Flow {} is not active, current status: {}", flowId, flow.getStatus());
                return CompletableFuture.completedFuture(false);
            }
            
            // Process flow steps based on the flow configuration
            // This would involve executing each step in the flow
            // and potentially sending messages, updating contact properties, etc.
            
            // For demonstration purposes, we'll simulate processing time
            Thread.sleep(1000);
            
            // Update flow statistics
            flow.setStartedCount(flow.getStartedCount() + 1);
            flow.setCompletedCount(flow.getCompletedCount() + 1);
            flowRepository.save(flow);
            
            logger.info("Successfully executed flow {} for contact {}", flowId, contactId);
            return CompletableFuture.completedFuture(true);
        } catch (Exception e) {
            logger.error("Error executing flow {} for contact {}", flowId, contactId, e);
            return CompletableFuture.completedFuture(false);
        }
    }
    
    /**
     * Asynchronously execute multiple flows in parallel
     */
    @Async("taskExecutor")
    public CompletableFuture<List<Boolean>> executeMultipleFlowsAsync(List<String> flowIds, String contactId, String triggerEvent) {
        logger.info("Executing {} flows for contact {}", flowIds.size(), contactId);
        
        List<CompletableFuture<Boolean>> futures = flowIds.stream()
            .map(flowId -> executeFlowAsync(flowId, contactId, triggerEvent))
            .toList();
        
        // Wait for all flows to be processed
        CompletableFuture<Void> allOf = CompletableFuture.allOf(
            futures.toArray(new CompletableFuture[0])
        );
        
        // When all flows are processed, collect the results
        return allOf.thenApply(v -> 
            futures.stream()
                .map(CompletableFuture::join)
                .toList()
        );
    }
}

package com.undrflow.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "subscriptions")
public class Subscription {
    
    @Id
    private String id;
    
    private String userId;
    
    private PlanType plan;
    
    private SubscriptionStatus status;
    
    private LocalDateTime startDate;
    
    private LocalDateTime endDate;
    
    private LocalDateTime trialEndsAt;
    
    private LocalDateTime canceledAt;
    
    private LocalDateTime currentPeriodStart;
    
    private LocalDateTime currentPeriodEnd;
    
    private Integer contactsLimit;
    
    private Integer currentContactsCount;
    
    private PaymentMethod paymentMethod;
    
    private BillingDetails billingDetails;
    
    private List<Invoice> invoices;
    
    public enum PlanType {
        FREE, PRO, PREMIUM, ENTERPRISE
    }
    
    public enum SubscriptionStatus {
        ACTIVE, CANCELED, PAST_DUE, TRIALING
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaymentMethod {
        private String type;
        private String last4;
        private Integer expiryMonth;
        private Integer expiryYear;
        private String brand;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BillingDetails {
        private String name;
        private String email;
        private Address address;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Address {
        private String line1;
        private String line2;
        private String city;
        private String state;
        private String postalCode;
        private String country;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Invoice {
        private String invoiceId;
        private Double amount;
        private String currency;
        private String status;
        private LocalDateTime date;
        private String pdfUrl;
    }
}

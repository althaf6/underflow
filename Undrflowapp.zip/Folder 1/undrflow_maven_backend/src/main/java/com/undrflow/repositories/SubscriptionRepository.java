package com.undrflow.repositories;

import com.undrflow.models.Subscription;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends MongoRepository<Subscription, String> {
    
    Optional<Subscription> findByUserId(String userId);
    
    List<Subscription> findByStatus(Subscription.SubscriptionStatus status);
    
    List<Subscription> findByEndDateBefore(LocalDateTime date);
    
    List<Subscription> findByTrialEndsAtBetween(LocalDateTime start, LocalDateTime end);
}

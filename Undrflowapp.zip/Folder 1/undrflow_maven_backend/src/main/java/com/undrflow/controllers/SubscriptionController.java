package com.undrflow.controllers;

import com.undrflow.models.User;
import com.undrflow.models.Subscription;
import com.undrflow.services.SubscriptionService;
import com.undrflow.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/subscription")
public class SubscriptionController {

    @Autowired
    private SubscriptionService subscriptionService;
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/current")
    public ResponseEntity<?> getCurrentSubscription() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.getSubscriptionByUserId(user.getId());
        return ResponseEntity.ok(subscription);
    }
    
    @PostMapping("/upgrade/pro")
    public ResponseEntity<?> upgradeToPro() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.upgradeToPro(user.getId());
        return ResponseEntity.ok(subscription);
    }
    
    @PostMapping("/upgrade/premium")
    public ResponseEntity<?> upgradeToPremium() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.upgradeToPremium(user.getId());
        return ResponseEntity.ok(subscription);
    }
    
    @PostMapping("/upgrade/enterprise")
    public ResponseEntity<?> upgradeToEnterprise(@RequestBody EnterpriseUpgradeRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.upgradeToEnterprise(user.getId(), request.getContactsLimit());
        return ResponseEntity.ok(subscription);
    }
    
    @PostMapping("/cancel")
    public ResponseEntity<?> cancelSubscription() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.cancelSubscription(user.getId());
        return ResponseEntity.ok(subscription);
    }
    
    @GetMapping("/feature-check/{featureName}")
    public ResponseEntity<?> checkFeatureAvailability(@PathVariable String featureName) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        boolean isAvailable = subscriptionService.isFeatureAvailable(user.getId(), featureName);
        
        Map<String, Boolean> response = new HashMap<>();
        response.put("available", isAvailable);
        
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/contact-limit")
    public ResponseEntity<?> getContactLimitInfo() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Subscription subscription = subscriptionService.getSubscriptionByUserId(user.getId());
        
        Map<String, Object> response = new HashMap<>();
        response.put("limit", subscription.getContactsLimit());
        response.put("current", subscription.getCurrentContactsCount());
        response.put("canAddMore", subscriptionService.canAddMoreContacts(user.getId()));
        
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/admin/expiring")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getExpiringSubscriptions() {
        return ResponseEntity.ok(subscriptionService.getExpiringSubscriptions());
    }
    
    @GetMapping("/admin/trial-ending")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getTrialEndingSubscriptions() {
        return ResponseEntity.ok(subscriptionService.getTrialEndingSubscriptions());
    }
    
    // Request classes
    
    public static class EnterpriseUpgradeRequest {
        private Integer contactsLimit;
        
        public Integer getContactsLimit() {
            return contactsLimit;
        }
        
        public void setContactsLimit(Integer contactsLimit) {
            this.contactsLimit = contactsLimit;
        }
    }
}

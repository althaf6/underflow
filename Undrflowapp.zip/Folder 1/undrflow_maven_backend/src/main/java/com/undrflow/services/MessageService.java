package com.undrflow.services;

import com.undrflow.models.Message;
import com.undrflow.repositories.MessageRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
public class MessageService {
    
    private static final Logger logger = LoggerFactory.getLogger(MessageService.class);
    
    private final MessageRepository messageRepository;
    
    @Autowired
    public MessageService(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }
    
    /**
     * Asynchronously send a message to a contact
     * This method will return immediately and process the message in a separate thread
     */
    @Async("messageExecutor")
    public CompletableFuture<Message> sendMessageAsync(Message message) {
        logger.info("Sending message asynchronously to contact: {}", message.getContactId());
        try {
            // Simulate API call to messaging platform
            Thread.sleep(500);
            message.setStatus("SENT");
            Message savedMessage = messageRepository.save(message);
            logger.info("Message sent successfully to contact: {}", message.getContactId());
            return CompletableFuture.completedFuture(savedMessage);
        } catch (Exception e) {
            logger.error("Error sending message to contact: {}", message.getContactId(), e);
            message.setStatus("FAILED");
            Message savedMessage = messageRepository.save(message);
            return CompletableFuture.completedFuture(savedMessage);
        }
    }
    
    /**
     * Asynchronously send messages to multiple contacts in parallel
     * This method uses CompletableFuture to process messages in parallel
     */
    @Async("messageExecutor")
    public CompletableFuture<List<Message>> sendBulkMessagesAsync(List<Message> messages) {
        logger.info("Sending bulk messages to {} contacts", messages.size());
        
        List<CompletableFuture<Message>> futures = messages.stream()
            .map(this::sendMessageAsync)
            .toList();
        
        // Wait for all messages to be processed
        CompletableFuture<Void> allOf = CompletableFuture.allOf(
            futures.toArray(new CompletableFuture[0])
        );
        
        // When all messages are processed, collect the results
        return allOf.thenApply(v -> 
            futures.stream()
                .map(CompletableFuture::join)
                .toList()
        );
    }
    
    /**
     * Get messages for a contact with pagination
     */
    public List<Message> getMessagesForContact(String contactId, int page, int size) {
        logger.info("Fetching messages for contact: {}, page: {}, size: {}", contactId, page, size);
        // Implementation would use repository pagination
        return messageRepository.findByContactIdOrderByCreatedAtDesc(contactId);
    }
    
    /**
     * Process incoming webhook message from messaging platform
     */
    @Async("messageExecutor")
    public CompletableFuture<Message> processIncomingMessage(Message message) {
        logger.info("Processing incoming message from contact: {}", message.getContactId());
        try {
            // Save the incoming message
            Message savedMessage = messageRepository.save(message);
            
            // Additional processing like triggering flows, etc.
            // This would be implemented based on business logic
            
            logger.info("Successfully processed incoming message from contact: {}", message.getContactId());
            return CompletableFuture.completedFuture(savedMessage);
        } catch (Exception e) {
            logger.error("Error processing incoming message from contact: {}", message.getContactId(), e);
            return CompletableFuture.failedFuture(e);
        }
    }
}

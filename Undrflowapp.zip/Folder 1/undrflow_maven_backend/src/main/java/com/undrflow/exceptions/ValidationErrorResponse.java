package com.undrflow.exceptions;

import java.util.Date;
import java.util.Map;

/**
 * Error response format for validation errors
 */
public class ValidationErrorResponse extends ErrorResponse {
    
    private Map<String, String> errors;
    
    public ValidationErrorResponse() {
        super();
    }
    
    public ValidationErrorResponse(Date timestamp, int status, String error, String message, 
                                  String path, Map<String, String> errors) {
        super(timestamp, status, error, message, path);
        this.errors = errors;
    }
    
    // Getters and Setters
    public Map<String, String> getErrors() {
        return errors;
    }
    
    public void setErrors(Map<String, String> errors) {
        this.errors = errors;
    }
}

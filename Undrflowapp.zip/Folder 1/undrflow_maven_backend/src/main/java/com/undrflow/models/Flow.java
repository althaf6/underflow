package com.undrflow.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "flows")
public class Flow {
    
    @Id
    private String id;
    
    private String userId;
    
    private String name;
    
    private String description;
    
    private FlowStatus status;
    
    private LocalDateTime createdAt;
    
    private LocalDateTime updatedAt;
    
    private LocalDateTime publishedAt;
    
    private List<Trigger> triggers;
    
    private List<Node> nodes;
    
    private Statistics statistics;
    
    public enum FlowStatus {
        DRAFT, ACTIVE, PAUSED, ARCHIVED
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Trigger {
        private String type;
        private String value;
        private Boolean active;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Node {
        private String id;
        private String type;
        private Position position;
        private Map<String, Object> data;
        private List<Connection> connections;
        
        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Position {
            private Integer x;
            private Integer y;
        }
        
        @Data
        @Builder
        @NoArgsConstructor
        @AllArgsConstructor
        public static class Connection {
            private String targetNodeId;
            private String condition;
        }
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Statistics {
        private Integer started;
        private Integer completed;
        private Double conversion;
        private Double averageCompletionTime;
    }
}

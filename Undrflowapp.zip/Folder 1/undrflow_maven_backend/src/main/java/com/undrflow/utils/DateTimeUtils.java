package com.undrflow.utils;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * Utility class for date and time operations
 */
public class DateTimeUtils {
    
    /**
     * Get current date and time
     * @return Current date
     */
    public static Date now() {
        return new Date();
    }
    
    /**
     * Calculate the difference between two dates in days
     * @param date1 First date
     * @param date2 Second date
     * @return Difference in days
     */
    public static long getDaysBetween(Date date1, Date date2) {
        long diffInMillies = Math.abs(date2.getTime() - date1.getTime());
        return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Calculate the difference between two dates in hours
     * @param date1 First date
     * @param date2 Second date
     * @return Difference in hours
     */
    public static long getHoursBetween(Date date1, Date date2) {
        long diffInMillies = Math.abs(date2.getTime() - date1.getTime());
        return TimeUnit.HOURS.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Calculate the difference between two dates in minutes
     * @param date1 First date
     * @param date2 Second date
     * @return Difference in minutes
     */
    public static long getMinutesBetween(Date date1, Date date2) {
        long diffInMillies = Math.abs(date2.getTime() - date1.getTime());
        return TimeUnit.MINUTES.convert(diffInMillies, TimeUnit.MILLISECONDS);
    }
    
    /**
     * Check if a date is before current date
     * @param date Date to check
     * @return true if date is in the past
     */
    public static boolean isPast(Date date) {
        return date.before(now());
    }
    
    /**
     * Check if a date is after current date
     * @param date Date to check
     * @return true if date is in the future
     */
    public static boolean isFuture(Date date) {
        return date.after(now());
    }
    
    /**
     * Add days to a date
     * @param date Base date
     * @param days Number of days to add
     * @return New date
     */
    public static Date addDays(Date date, int days) {
        return new Date(date.getTime() + TimeUnit.DAYS.toMillis(days));
    }
    
    /**
     * Add hours to a date
     * @param date Base date
     * @param hours Number of hours to add
     * @return New date
     */
    public static Date addHours(Date date, int hours) {
        return new Date(date.getTime() + TimeUnit.HOURS.toMillis(hours));
    }
    
    /**
     * Add minutes to a date
     * @param date Base date
     * @param minutes Number of minutes to add
     * @return New date
     */
    public static Date addMinutes(Date date, int minutes) {
        return new Date(date.getTime() + TimeUnit.MINUTES.toMillis(minutes));
    }
}

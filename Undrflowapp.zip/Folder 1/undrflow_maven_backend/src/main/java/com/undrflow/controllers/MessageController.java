package com.undrflow.controllers;

import com.undrflow.models.Message;
import com.undrflow.models.User;
import com.undrflow.services.ContactService;
import com.undrflow.services.MessageService;
import com.undrflow.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/messages")
public class MessageController {

    @Autowired
    private MessageService messageService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ContactService contactService;
    
    @PostMapping
    public ResponseEntity<?> createMessage(@RequestBody Message message) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Message createdMessage = messageService.createMessage(message, user.getId());
        
        // Update contact conversation history
        if (message.getContactId() != null) {
            contactService.addConversationHistoryEntry(
                message.getContactId(),
                user.getId(),
                createdMessage.getId(),
                message.getDirection(),
                message.getChannel()
            );
        }
        
        return ResponseEntity.ok(createdMessage);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> getMessageById(@PathVariable String id) {
        Message message = messageService.getMessageById(id);
        return ResponseEntity.ok(message);
    }
    
    @GetMapping("/conversation/{contactId}")
    public ResponseEntity<?> getConversationMessages(
            @PathVariable String contactId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "sentAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        
        Page<Message> messages = messageService.getConversationMessages(user.getId(), contactId, pageable);
        
        Map<String, Object> response = new HashMap<>();
        response.put("messages", messages.getContent());
        response.put("currentPage", messages.getNumber());
        response.put("totalItems", messages.getTotalElements());
        response.put("totalPages", messages.getTotalPages());
        
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/flow/{flowId}")
    public ResponseEntity<?> getFlowMessages(@PathVariable String flowId) {
        List<Message> messages = messageService.getFlowMessages(flowId);
        return ResponseEntity.ok(messages);
    }
    
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateMessageStatus(@PathVariable String id, @RequestBody StatusUpdateRequest request) {
        Message updatedMessage = messageService.updateMessageStatus(id, request.getStatus());
        return ResponseEntity.ok(updatedMessage);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getMessagesByStatus(@PathVariable String status) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Message.MessageStatus messageStatus = Message.MessageStatus.valueOf(status.toUpperCase());
        List<Message> messages = messageService.getMessagesByStatus(user.getId(), messageStatus);
        return ResponseEntity.ok(messages);
    }
    
    @GetMapping("/date-range")
    public ResponseEntity<?> getMessagesByDateRange(
            @RequestParam String startDate,
            @RequestParam String endDate) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        LocalDateTime start = LocalDateTime.parse(startDate, formatter);
        LocalDateTime end = LocalDateTime.parse(endDate, formatter);
        
        List<Message> messages = messageService.getMessagesByDateRange(user.getId(), start, end);
        return ResponseEntity.ok(messages);
    }
    
    @GetMapping("/stats")
    public ResponseEntity<?> getMessageStats() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("sent", messageService.countMessagesByDirection(user.getId(), "outgoing"));
        stats.put("received", messageService.countMessagesByDirection(user.getId(), "incoming"));
        
        Map<String, Long> channelStats = new HashMap<>();
        channelStats.put("facebook", messageService.countMessagesByChannel(user.getId(), "facebook"));
        channelStats.put("instagram", messageService.countMessagesByChannel(user.getId(), "instagram"));
        channelStats.put("whatsapp", messageService.countMessagesByChannel(user.getId(), "whatsapp"));
        
        stats.put("channels", channelStats);
        
        return ResponseEntity.ok(stats);
    }
    
    // Request and Response classes
    
    public static class StatusUpdateRequest {
        private Message.MessageStatus status;
        
        public Message.MessageStatus getStatus() {
            return status;
        }
        
        public void setStatus(Message.MessageStatus status) {
            this.status = status;
        }
    }
}

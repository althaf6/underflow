package com.undrflow.controllers;

import com.undrflow.models.Contact;
import com.undrflow.models.User;
import com.undrflow.services.ContactService;
import com.undrflow.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/contacts")
public class ContactController {

    @Autowired
    private ContactService contactService;
    
    @Autowired
    private UserService userService;
    
    @GetMapping
    public ResponseEntity<?> getAllContacts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Sort.Direction sortDirection = direction.equalsIgnoreCase("asc") ? Sort.Direction.ASC : Sort.Direction.DESC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(sortDirection, sortBy));
        
        Page<Contact> contacts = contactService.getUserContacts(user.getId(), pageable);
        
        Map<String, Object> response = new HashMap<>();
        response.put("contacts", contacts.getContent());
        response.put("currentPage", contacts.getNumber());
        response.put("totalItems", contacts.getTotalElements());
        response.put("totalPages", contacts.getTotalPages());
        
        return ResponseEntity.ok(response);
    }
    
    @PostMapping
    public ResponseEntity<?> createContact(@RequestBody Contact contact) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Contact createdContact = contactService.createContact(contact, user.getId());
        return ResponseEntity.ok(createdContact);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<?> getContactById(@PathVariable String id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Contact contact = contactService.getContactById(id, user.getId());
        return ResponseEntity.ok(contact);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<?> updateContact(@PathVariable String id, @RequestBody Contact contactDetails) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Contact updatedContact = contactService.updateContact(id, contactDetails, user.getId());
        return ResponseEntity.ok(updatedContact);
    }
    
    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateContactStatus(@PathVariable String id, @RequestBody StatusUpdateRequest request) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Contact updatedContact = contactService.updateContactStatus(id, request.getStatus(), user.getId());
        return ResponseEntity.ok(updatedContact);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteContact(@PathVariable String id) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        contactService.deleteContact(id, user.getId());
        return ResponseEntity.ok(new MessageResponse("Contact deleted successfully"));
    }
    
    @GetMapping("/tag/{tag}")
    public ResponseEntity<?> getContactsByTag(@PathVariable String tag) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        List<Contact> contacts = contactService.getContactsByTag(user.getId(), tag);
        return ResponseEntity.ok(contacts);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getContactsByStatus(@PathVariable String status) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Contact.ContactStatus contactStatus = Contact.ContactStatus.valueOf(status.toUpperCase());
        List<Contact> contacts = contactService.getContactsByStatus(user.getId(), contactStatus);
        return ResponseEntity.ok(contacts);
    }
    
    @GetMapping("/inactive/{days}")
    public ResponseEntity<?> getInactiveContacts(@PathVariable int days) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        List<Contact> contacts = contactService.getInactiveContacts(user.getId(), days);
        return ResponseEntity.ok(contacts);
    }
    
    @GetMapping("/count")
    public ResponseEntity<?> getContactCount() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User user = userService.getUserByEmail(email);
        
        Map<String, Object> response = new HashMap<>();
        response.put("total", contactService.getContactCount(user.getId()));
        response.put("active", contactService.getActiveContactCount(user.getId()));
        
        return ResponseEntity.ok(response);
    }
    
    // Request and Response classes
    
    public static class StatusUpdateRequest {
        private Contact.ContactStatus status;
        
        public Contact.ContactStatus getStatus() {
            return status;
        }
        
        public void setStatus(Contact.ContactStatus status) {
            this.status = status;
        }
    }
    
    public static class MessageResponse {
        private String message;
        
        public MessageResponse(String message) {
            this.message = message;
        }
        
        public String getMessage() {
            return message;
        }
        
        public void setMessage(String message) {
            this.message = message;
        }
    }
}

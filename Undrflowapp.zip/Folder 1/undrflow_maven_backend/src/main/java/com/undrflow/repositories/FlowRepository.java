package com.undrflow.repositories;

import com.undrflow.models.Flow;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FlowRepository extends MongoRepository<Flow, String> {
    
    Page<Flow> findByUserId(String userId, Pageable pageable);
    
    List<Flow> findByUserIdAndStatus(String userId, Flow.FlowStatus status);
    
    @Query("{'userId': ?0, 'triggers.type': ?1, 'triggers.value': ?2, 'status': 'ACTIVE'}")
    List<Flow> findActiveFlowsByTrigger(String userId, String triggerType, String triggerValue);
    
    long countByUserIdAndStatus(String userId, Flow.FlowStatus status);
}

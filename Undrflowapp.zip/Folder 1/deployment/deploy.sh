#!/bin/bash

# Undrflow Deployment Script for Render
# This script prepares the application for deployment to Render

echo "Preparing Undrflow for deployment to Render..."

# Create build directories if they don't exist
mkdir -p build/backend
mkdir -p build/admin
mkdir -p build/consumer

# Backend preparation
echo "Preparing Spring Boot backend..."
cd backend

# Update application.properties for production
cat > src/main/resources/application-prod.properties << EOL
# Production Configuration
spring.data.mongodb.uri=${MONGODB_URI}
server.port=${PORT:8080}

# JWT Configuration
jwt.secret=${JWT_SECRET}
jwt.expiration=86400000

# Google OAuth Configuration
spring.security.oauth2.client.registration.google.client-id=${GOOGLE_CLIENT_ID}
spring.security.oauth2.client.registration.google.client-secret=${GOOGLE_CLIENT_SECRET}
spring.security.oauth2.client.registration.google.scope=email,profile

# Logging Configuration
logging.level.root=INFO
logging.level.com.undrflow=INFO
logging.pattern.console=%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n

# Async Thread Pool Configuration
async.core-pool-size=5
async.max-pool-size=10
async.queue-capacity=25

# Cache Configuration
spring.cache.type=caffeine
spring.cache.caffeine.spec=maximumSize=500,expireAfterAccess=600s
EOL

# Create Procfile for Render
echo "web: java -jar build/libs/undrflow-0.0.1-SNAPSHOT.jar" > Procfile

# Create system.properties to specify Java version
echo "java.runtime.version=17" > system.properties

# Return to root directory
cd ..

# Admin frontend preparation
echo "Preparing admin frontend..."
cd frontend/admin

# Create next.config.js with production settings
cat > next.config.js << EOL
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  output: 'standalone',
  env: {
    API_URL: process.env.NEXT_PUBLIC_API_URL || 'https://undrflow-backend.onrender.com',
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: '\${process.env.NEXT_PUBLIC_API_URL}/:path*',
      },
    ];
  },
}

module.exports = nextConfig
EOL

# Create .env.production file
cat > .env.production << EOL
NEXT_PUBLIC_API_URL=https://undrflow-backend.onrender.com
EOL

# Return to root directory
cd ../..

# Consumer frontend preparation
echo "Preparing consumer frontend..."
cd frontend/consumer

# Create next.config.js with production settings
cat > next.config.js << EOL
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  output: 'standalone',
  env: {
    API_URL: process.env.NEXT_PUBLIC_API_URL || 'https://undrflow-backend.onrender.com',
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: '\${process.env.NEXT_PUBLIC_API_URL}/:path*',
      },
    ];
  },
}

module.exports = nextConfig
EOL

# Create .env.production file
cat > .env.production << EOL
NEXT_PUBLIC_API_URL=https://undrflow-backend.onrender.com
EOL

# Return to root directory
cd ../..

# Create a README for deployment
cat > DEPLOY.md << EOL
# Undrflow Deployment Guide

This guide explains how to deploy Undrflow to Render.

## Prerequisites

1. A Render account (https://render.com)
2. A MongoDB Atlas account for the database (https://www.mongodb.com/cloud/atlas)

## Deployment Steps

### 1. Set up MongoDB Atlas

1. Create a new MongoDB Atlas cluster (free tier is sufficient for starting)
2. Create a database user with read/write permissions
3. Configure network access to allow connections from anywhere (or specifically from Render IPs)
4. Get your MongoDB connection string

### 2. Deploy to Render

#### Option 1: Using the Render Dashboard

1. Fork the Undrflow repository to your GitHub account
2. In the Render dashboard, click "New" and select "Blueprint"
3. Connect your GitHub account and select the Undrflow repository
4. Render will automatically detect the render.yaml file and set up the services
5. Configure the environment variables:
   - MONGODB_URI: Your MongoDB Atlas connection string
   - JWT_SECRET: A secure random string for JWT token signing
   - GOOGLE_CLIENT_ID: Your Google OAuth client ID
   - GOOGLE_CLIENT_SECRET: Your Google OAuth client secret
6. Click "Apply" to start the deployment

#### Option 2: Using the Render CLI

1. Install the Render CLI: \`npm install -g @render/cli\`
2. Login to your Render account: \`render login\`
3. Deploy the blueprint: \`render blueprint apply\`
4. Follow the prompts to set the required environment variables

## Post-Deployment

After deployment is complete:

1. The backend API will be available at: https://undrflow-backend.onrender.com
2. The admin interface will be available at: https://undrflow-admin.onrender.com
3. The consumer interface will be available at: https://undrflow-consumer.onrender.com

## Troubleshooting

If you encounter any issues during deployment:

1. Check the logs in the Render dashboard for each service
2. Verify that all environment variables are correctly set
3. Ensure your MongoDB Atlas cluster is properly configured and accessible
4. Check that your Google OAuth credentials are correct and have the necessary permissions

For more detailed information, refer to the full documentation PDF.
EOL

echo "Deployment preparation complete! You can now deploy to Render using the render.yaml file."
echo "See DEPLOY.md for detailed instructions."

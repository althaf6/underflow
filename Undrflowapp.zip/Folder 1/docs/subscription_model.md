# Undrflow Subscription Model Design

## Authentication Methods
- Email and password login
- Google OAuth integration

## User Types
1. **Admin/Owner**
   - Full access to all platform features
   - Analytics dashboard
   - User management capabilities
   - Ability to create and manage influencer accounts

2. **Influencers/Users**
   - Access based on subscription tier
   - Marketing automation tools
   - Campaign management
   - Analytics for their own campaigns

## Subscription Tiers

### Free Tier (Available only after login)
- **Features:**
  - Up to 500 contacts
  - Basic chatbot builder
  - Single platform integration (Facebook Messenger only)
  - Limited templates (5)
  - Basic analytics
  - 5 automation flows
  - Undrflow branding on messages
  - Community support only
  - 3 custom tags for segmentation

- **Limitations:**
  - No AI features
  - No advanced segmentation
  - No API access
  - Limited broadcast messages (5/month)

### Pro Tier ($12/month)
- **Features:**
  - Up to 2,000 contacts (additional contacts at scaled pricing)
  - Advanced chatbot builder
  - Multi-platform integration (Facebook, Instagram, WhatsApp)
  - 20+ templates
  - Detailed analytics and reporting
  - Unlimited automation flows
  - No Undrflow branding
  - Email support
  - Unlimited custom tags
  - Basic AI features (text improvement, simple intent recognition)
  - API access for custom integrations
  - Unlimited broadcast messages

### Premium Tier ($29/month)
- **Features:**
  - Up to 10,000 contacts (additional contacts at scaled pricing)
  - All Pro features
  - All platform integrations (including SMS, Email, TikTok)
  - 50+ premium templates
  - Advanced analytics with custom reports
  - Advanced AI features (full intent recognition, AI flow builder)
  - Priority email support
  - Phone support during business hours
  - Advanced segmentation
  - A/B testing capabilities
  - Team collaboration features

### Enterprise Tier (Custom pricing)
- **Features:**
  - Unlimited contacts
  - All Premium features
  - Dedicated account manager
  - Custom feature development
  - White-label options
  - 24/7 priority support
  - Custom integrations
  - Advanced security features
  - Multi-team management
  - Training and onboarding

## Contact Pricing Scale
- **Pro Tier:**
  - 2,001-5,000 contacts: +$5/month
  - 5,001-10,000 contacts: +$10/month
  - 10,001-25,000 contacts: +$20/month
  - 25,001-50,000 contacts: +$35/month
  - 50,001+ contacts: Enterprise tier required

- **Premium Tier:**
  - 10,001-25,000 contacts: +$15/month
  - 25,001-50,000 contacts: +$25/month
  - 50,001-100,000 contacts: +$40/month
  - 100,001+ contacts: Enterprise tier required

## Billing Options
- Monthly subscription (default)
- Annual subscription (15% discount)
- Payment methods: Credit/debit cards, PayPal

## Free Trial
- 14-day free trial of Premium tier features
- No credit card required for trial
- Automatic downgrade to Free tier after trial period

## Upgrade/Downgrade Policy
- Upgrade anytime, changes effective immediately
- Downgrade effective at the end of the current billing cycle
- Prorated refunds for downgrades from annual plans

## Special Offers
- Referral program: 20% commission on referred users' first 3 months
- Nonprofit discount: 30% off any paid tier

import weasyprint
import os

# Define input and output paths
html_path = '/home/ubuntu/undrflow/docs/pdf/undrflow_documentation.html'
pdf_path = '/home/ubuntu/undrflow/docs/pdf/Undrflow_Documentation.pdf'

# Convert HTML to PDF
html = weasyprint.HTML(filename=html_path)
pdf = html.write_pdf()

# Save the PDF
with open(pdf_path, 'wb') as f:
    f.write(pdf)

print(f"PDF successfully created at: {pdf_path}")

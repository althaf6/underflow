# Undrflow Database Schema Design

## Overview
Undrflow will use MongoDB as its primary database, leveraging its flexibility and scalability for handling various data types required by the application. The schema design follows a document-oriented approach with appropriate references between collections.

## Collections

### Users Collection
```json
{
  "_id": "ObjectId",
  "email": "String (unique, required)",
  "password": "String (hashed, required for email login)",
  "googleId": "String (for Google OAuth)",
  "firstName": "String",
  "lastName": "String",
  "profilePicture": "String (URL)",
  "role": "String (enum: 'admin', 'user')",
  "status": "String (enum: 'active', 'inactive', 'suspended')",
  "createdAt": "Date",
  "updatedAt": "Date",
  "lastLoginAt": "Date",
  "settings": {
    "notifications": {
      "email": "Boolean",
      "inApp": "Boolean"
    },
    "timezone": "String",
    "language": "String"
  }
}
```

### Subscriptions Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "plan": "String (enum: 'free', 'pro', 'premium', 'enterprise')",
  "status": "String (enum: 'active', 'canceled', 'past_due', 'trialing')",
  "startDate": "Date",
  "endDate": "Date",
  "trialEndsAt": "Date",
  "canceledAt": "Date",
  "currentPeriodStart": "Date",
  "currentPeriodEnd": "Date",
  "contactsLimit": "Number",
  "currentContactsCount": "Number",
  "paymentMethod": {
    "type": "String (enum: 'card', 'paypal')",
    "last4": "String",
    "expiryMonth": "Number",
    "expiryYear": "Number",
    "brand": "String"
  },
  "billingDetails": {
    "name": "String",
    "email": "String",
    "address": {
      "line1": "String",
      "line2": "String",
      "city": "String",
      "state": "String",
      "postalCode": "String",
      "country": "String"
    }
  },
  "invoices": [
    {
      "invoiceId": "String",
      "amount": "Number",
      "currency": "String",
      "status": "String (enum: 'paid', 'unpaid', 'void')",
      "date": "Date",
      "pdfUrl": "String"
    }
  ]
}
```

### Contacts Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "firstName": "String",
  "lastName": "String",
  "email": "String",
  "phone": "String",
  "source": "String (enum: 'facebook', 'instagram', 'whatsapp', 'manual', etc.)",
  "tags": ["String"],
  "customFields": {
    "field1": "Mixed",
    "field2": "Mixed",
    // Dynamic custom fields
  },
  "status": "String (enum: 'active', 'unsubscribed', 'bounced')",
  "lastInteractionAt": "Date",
  "createdAt": "Date",
  "updatedAt": "Date",
  "notes": "String",
  "conversationHistory": [
    {
      "messageId": "ObjectId (ref: Messages)",
      "timestamp": "Date",
      "direction": "String (enum: 'incoming', 'outgoing')",
      "channel": "String (enum: 'facebook', 'instagram', 'whatsapp', etc.)"
    }
  ]
}
```

### Flows Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "name": "String",
  "description": "String",
  "status": "String (enum: 'draft', 'active', 'paused', 'archived')",
  "createdAt": "Date",
  "updatedAt": "Date",
  "publishedAt": "Date",
  "triggers": [
    {
      "type": "String (enum: 'keyword', 'button', 'url', 'api', etc.)",
      "value": "String",
      "active": "Boolean"
    }
  ],
  "nodes": [
    {
      "id": "String (unique within flow)",
      "type": "String (enum: 'message', 'condition', 'delay', 'action', 'ai')",
      "position": {
        "x": "Number",
        "y": "Number"
      },
      "data": {
        // Dynamic based on node type
        "content": "String",
        "buttons": [
          {
            "text": "String",
            "value": "String",
            "type": "String (enum: 'url', 'next', 'phone', etc.)"
          }
        ],
        "delay": "Number",
        "condition": "Object",
        "actionType": "String",
        "actionConfig": "Object"
      },
      "connections": [
        {
          "targetNodeId": "String",
          "condition": "String (optional)"
        }
      ]
    }
  ],
  "statistics": {
    "started": "Number",
    "completed": "Number",
    "conversion": "Number",
    "averageCompletionTime": "Number"
  }
}
```

### Messages Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "flowId": "ObjectId (ref: Flows, optional)",
  "contactId": "ObjectId (ref: Contacts)",
  "direction": "String (enum: 'incoming', 'outgoing')",
  "channel": "String (enum: 'facebook', 'instagram', 'whatsapp', etc.)",
  "type": "String (enum: 'text', 'image', 'video', 'file', 'button', etc.)",
  "content": "String",
  "attachments": [
    {
      "type": "String",
      "url": "String",
      "name": "String",
      "size": "Number"
    }
  ],
  "metadata": {
    "platformMessageId": "String",
    "nodeId": "String (from flow)",
    "buttons": [
      {
        "text": "String",
        "value": "String",
        "type": "String"
      }
    ]
  },
  "status": "String (enum: 'sent', 'delivered', 'read', 'failed')",
  "sentAt": "Date",
  "deliveredAt": "Date",
  "readAt": "Date",
  "createdAt": "Date"
}
```

### Channels Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "type": "String (enum: 'facebook', 'instagram', 'whatsapp', etc.)",
  "name": "String",
  "status": "String (enum: 'connected', 'disconnected', 'error')",
  "credentials": {
    "accessToken": "String (encrypted)",
    "refreshToken": "String (encrypted)",
    "expiresAt": "Date",
    "pageId": "String",
    "pageName": "String"
  },
  "settings": {
    "defaultReplyEnabled": "Boolean",
    "defaultReplyMessage": "String",
    "autoResponseEnabled": "Boolean",
    "workingHours": {
      "enabled": "Boolean",
      "timezone": "String",
      "schedule": [
        {
          "day": "Number (0-6, 0 is Sunday)",
          "start": "String (HH:MM)",
          "end": "String (HH:MM)"
        }
      ],
      "outOfHoursMessage": "String"
    }
  },
  "stats": {
    "messagesSent": "Number",
    "messagesReceived": "Number",
    "lastActivityAt": "Date"
  },
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Broadcasts Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "name": "String",
  "status": "String (enum: 'draft', 'scheduled', 'sending', 'sent', 'canceled')",
  "channel": "String (enum: 'facebook', 'instagram', 'whatsapp', etc.)",
  "message": {
    "type": "String (enum: 'text', 'image', 'video', 'file', etc.)",
    "content": "String",
    "attachments": [
      {
        "type": "String",
        "url": "String",
        "name": "String"
      }
    ],
    "buttons": [
      {
        "text": "String",
        "value": "String",
        "type": "String"
      }
    ]
  },
  "audience": {
    "type": "String (enum: 'all', 'segment', 'tags', 'custom')",
    "segmentId": "ObjectId (ref: Segments, optional)",
    "tags": ["String"],
    "customFilter": "Object"
  },
  "schedule": {
    "sendAt": "Date",
    "timezone": "String"
  },
  "stats": {
    "totalContacts": "Number",
    "sent": "Number",
    "delivered": "Number",
    "read": "Number",
    "clicked": "Number",
    "failed": "Number"
  },
  "createdAt": "Date",
  "updatedAt": "Date",
  "sentAt": "Date"
}
```

### Segments Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "name": "String",
  "description": "String",
  "filters": [
    {
      "field": "String",
      "operator": "String (enum: 'equals', 'contains', 'greater_than', etc.)",
      "value": "Mixed",
      "type": "String (enum: 'contact_field', 'custom_field', 'tag', 'interaction')"
    }
  ],
  "contactCount": "Number",
  "createdAt": "Date",
  "updatedAt": "Date",
  "lastCalculatedAt": "Date"
}
```

### Analytics Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "date": "Date",
  "metrics": {
    "newContacts": "Number",
    "activeContacts": "Number",
    "messagesSent": "Number",
    "messagesReceived": "Number",
    "flowsStarted": "Number",
    "flowsCompleted": "Number",
    "broadcastsSent": "Number",
    "clickThroughRate": "Number",
    "conversionRate": "Number"
  },
  "channelMetrics": {
    "facebook": {
      "messagesSent": "Number",
      "messagesReceived": "Number",
      "newContacts": "Number"
    },
    "instagram": {
      "messagesSent": "Number",
      "messagesReceived": "Number",
      "newContacts": "Number"
    },
    "whatsapp": {
      "messagesSent": "Number",
      "messagesReceived": "Number",
      "newContacts": "Number"
    }
  }
}
```

### Templates Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "name": "String",
  "description": "String",
  "category": "String (enum: 'welcome', 'promotion', 'follow-up', etc.)",
  "type": "String (enum: 'flow', 'message')",
  "content": "Mixed (depends on type)",
  "thumbnail": "String (URL)",
  "isPublic": "Boolean",
  "isOfficial": "Boolean",
  "usageCount": "Number",
  "rating": "Number",
  "createdAt": "Date",
  "updatedAt": "Date"
}
```

### Webhooks Collection
```json
{
  "_id": "ObjectId",
  "userId": "ObjectId (ref: Users)",
  "name": "String",
  "url": "String",
  "events": ["String (enum: 'message.received', 'contact.created', etc.)"],
  "secret": "String",
  "status": "String (enum: 'active', 'inactive')",
  "createdAt": "Date",
  "updatedAt": "Date",
  "lastTriggeredAt": "Date",
  "stats": {
    "success": "Number",
    "failed": "Number",
    "lastStatusCode": "Number",
    "lastResponse": "String"
  }
}
```

## Indexes

### Users Collection
- `email`: Unique index
- `googleId`: Sparse index

### Subscriptions Collection
- `userId`: Index
- `status`: Index
- `endDate`: Index

### Contacts Collection
- `userId`: Index
- `email`: Index
- `phone`: Index
- `tags`: Index
- `status`: Index
- `userId_email`: Compound index

### Flows Collection
- `userId`: Index
- `status`: Index
- `triggers.value`: Index

### Messages Collection
- `userId`: Index
- `contactId`: Index
- `flowId`: Index
- `sentAt`: Index
- `userId_contactId`: Compound index

### Channels Collection
- `userId`: Index
- `type`: Index
- `userId_type`: Compound index

### Broadcasts Collection
- `userId`: Index
- `status`: Index
- `schedule.sendAt`: Index

### Segments Collection
- `userId`: Index

### Analytics Collection
- `userId`: Index
- `date`: Index
- `userId_date`: Compound index

### Templates Collection
- `userId`: Index
- `category`: Index
- `isPublic`: Index

### Webhooks Collection
- `userId`: Index
- `events`: Index

## Data Relationships

1. **User to Subscriptions**: One-to-one relationship
2. **User to Contacts**: One-to-many relationship
3. **User to Flows**: One-to-many relationship
4. **User to Channels**: One-to-many relationship
5. **User to Broadcasts**: One-to-many relationship
6. **User to Segments**: One-to-many relationship
7. **User to Templates**: One-to-many relationship
8. **User to Webhooks**: One-to-many relationship
9. **Flow to Messages**: One-to-many relationship
10. **Contact to Messages**: One-to-many relationship
11. **Segment to Contacts**: Many-to-many relationship (via filters)
12. **Broadcast to Contacts**: Many-to-many relationship (via audience)

## Data Migration Strategy

1. **Versioning**: Schema version tracking for future migrations
2. **Backward Compatibility**: Maintain backward compatibility during schema changes
3. **Migration Scripts**: Automated scripts for schema updates
4. **Data Validation**: Validate data integrity before and after migrations
5. **Rollback Plan**: Ability to revert to previous schema version if needed

## Data Security Considerations

1. **Encryption**: Sensitive data (tokens, credentials) stored encrypted
2. **Access Control**: Field-level access control based on user roles
3. **Data Isolation**: Strict tenant isolation for multi-tenant architecture
4. **Audit Logging**: Track changes to sensitive data
5. **Data Retention**: Policies for data retention and deletion
6. **Compliance**: GDPR and other regulatory compliance measures

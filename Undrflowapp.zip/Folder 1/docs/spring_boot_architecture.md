# Undrflow System Architecture with Spring Boot

## Overview
Undrflow will be built as a modern web application with a clear separation between frontend and backend components. The backend will be implemented using Spring Boot, providing a robust, scalable, and maintainable foundation for the application.

## Technology Stack

### Frontend
- **Framework**: React.js with Next.js
- **State Management**: Redux Toolkit
- **UI Components**: Custom components following CRED-like neumorphic design
- **Styling**: Tailwind CSS with custom theme
- **Authentication**: JWT-based authentication with Spring Security integration

### Backend
- **Framework**: Spring Boot 3.x
- **Language**: Java 17
- **Database**: MongoDB (NoSQL)
- **Authentication**: Spring Security with JWT
- **API Documentation**: SpringDoc OpenAPI (Swagger)
- **Real-time Communication**: WebSocket with STOMP
- **File Storage**: AWS S3 compatible (using MinIO for self-hosting)
- **Caching**: Redis with Spring Cache
- **Task Scheduling**: Spring Scheduler and Quartz

### DevOps
- **Containerization**: Docker
- **Deployment**: Docker Compose for easy self-hosting
- **CI/CD**: GitHub Actions
- **Monitoring**: Spring Actuator, Prometheus, and Grafana

## System Components

### 1. Authentication Service
- Handles user registration and login
- Manages OAuth integrations (Google)
- Issues and validates JWT tokens
- Manages user sessions
- Implements with Spring Security

### 2. User Management Service
- Manages user profiles and settings
- Handles subscription management
- Processes role-based access control
- Manages teams and collaborators

### 3. Chatbot Builder Service
- Provides visual flow builder functionality
- Manages conversation templates
- Handles natural language processing
- Integrates with AI services

### 4. Channel Integration Service
- Manages connections to messaging platforms
- Handles webhook events from platforms
- Normalizes message formats across platforms
- Manages platform-specific rate limits

### 5. Analytics Service
- Collects and processes user interaction data
- Generates reports and insights
- Provides real-time dashboards
- Handles data export functionality

### 6. Notification Service
- Manages in-app notifications
- Handles email notifications using Spring Mail
- Processes scheduled messages
- Manages broadcast campaigns

### 7. Billing Service
- Processes subscription payments
- Handles invoicing and receipts
- Manages subscription upgrades/downgrades
- Integrates with payment gateways

## Spring Boot Application Structure

```
com.undrflow
├── UndrflowApplication.java (Main application class)
├── controllers (REST API endpoints)
│   ├── AuthController.java
│   ├── UserController.java
│   ├── FlowController.java
│   ├── ContactController.java
│   ├── ChannelController.java
│   ├── BroadcastController.java
│   ├── AnalyticsController.java
│   └── WebhookController.java
├── models (Domain entities)
│   ├── User.java
│   ├── Subscription.java
│   ├── Contact.java
│   ├── Flow.java
│   ├── Message.java
│   ├── Channel.java
│   ├── Broadcast.java
│   ├── Segment.java
│   ├── Template.java
│   └── Webhook.java
├── repositories (MongoDB repositories)
│   ├── UserRepository.java
│   ├── SubscriptionRepository.java
│   ├── ContactRepository.java
│   ├── FlowRepository.java
│   ├── MessageRepository.java
│   ├── ChannelRepository.java
│   ├── BroadcastRepository.java
│   ├── SegmentRepository.java
│   ├── TemplateRepository.java
│   └── WebhookRepository.java
├── services (Business logic)
│   ├── AuthService.java
│   ├── UserService.java
│   ├── SubscriptionService.java
│   ├── ContactService.java
│   ├── FlowService.java
│   ├── MessageService.java
│   ├── ChannelService.java
│   ├── BroadcastService.java
│   ├── AnalyticsService.java
│   ├── WebhookService.java
│   └── NotificationService.java
├── config (Application configuration)
│   ├── MongoConfig.java
│   ├── RedisConfig.java
│   ├── WebSocketConfig.java
│   ├── S3Config.java
│   ├── AsyncConfig.java
│   └── SchedulerConfig.java
├── security (Authentication and authorization)
│   ├── JwtTokenProvider.java
│   ├── JwtAuthenticationFilter.java
│   ├── UserDetailsServiceImpl.java
│   ├── SecurityConfig.java
│   └── OAuth2Config.java
└── utils (Utility classes)
    ├── Constants.java
    ├── DateUtils.java
    ├── ValidationUtils.java
    ├── FileUtils.java
    └── ResponseUtils.java
```

## Architecture Diagram
```
┌─────────────────────────────────────────────────────────────────┐
│                        Client Applications                       │
│  ┌───────────────┐              ┌───────────────────────────┐   │
│  │ Admin Interface│              │ Consumer/User Interface   │   │
│  └───────────────┘              └───────────────────────────┘   │
└───────────────────────────────────────────────────────────────┬─┘
                                                               │
┌──────────────────────────────────────────────────────────────┼─┐
│                            API Gateway                        │ │
└──────────────────────────────────────────────────────────────┼─┘
                                                               │
┌──────────────────────────────────────────────────────────────┼─┐
│                      Spring Boot Application                  │ │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐     │ │
│  │ Authentication│  │User Management│  │Chatbot Builder│     │ │
│  └───────────────┘  └───────────────┘  └───────────────┘     │ │
│                                                              │ │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐     │ │
│  │Channel Integr.│  │   Analytics   │  │ Notifications │     │ │
│  └───────────────┘  └───────────────┘  └───────────────┘     │ │
│                                                              │ │
│  ┌───────────────┐                                           │ │
│  │    Billing    │                                           │ │
│  └───────────────┘                                           │ │
└──────────────────────────────────────────────────────────────┼─┘
                                                               │
┌──────────────────────────────────────────────────────────────┼─┐
│                        Data Layer                             │ │
│  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐     │ │
│  │    MongoDB    │  │     Redis     │  │  File Storage │     │ │
│  └───────────────┘  └───────────────┘  └───────────────┘     │ │
└──────────────────────────────────────────────────────────────┴─┘
```

## Spring Boot Specific Features

### 1. Dependency Injection
- Leveraging Spring's powerful IoC container
- Constructor-based dependency injection
- Component scanning for automatic bean registration

### 2. Spring Data MongoDB
- Repository pattern implementation
- Custom query methods
- MongoDB template for complex operations
- Reactive repositories for non-blocking operations

### 3. Spring Security
- JWT-based authentication
- Role-based authorization
- Method-level security with annotations
- CORS and CSRF protection
- OAuth2 integration for Google login

### 4. Spring WebSocket
- Real-time communication for chat features
- STOMP protocol for message routing
- User-specific messaging
- Session management

### 5. Spring Scheduler
- Scheduled tasks for recurring operations
- Cron expressions for flexible scheduling
- Asynchronous task execution
- Quartz integration for distributed scheduling

### 6. Spring Cache
- Redis-based caching
- Cache abstraction for simplified usage
- Conditional caching with SpEL
- Cache eviction strategies

### 7. Spring Actuator
- Health checks and monitoring endpoints
- Metrics collection for Prometheus
- Audit events
- Environment information

## API Design Principles
- RESTful API design
- Consistent URL patterns
- Proper HTTP method usage
- Comprehensive error handling
- Versioning strategy
- Pagination for large result sets
- Filtering and sorting capabilities
- HATEOAS for discoverability

## Scalability Considerations
- Stateless application design
- Horizontal scaling of services
- Database sharding for high-volume data
- Caching strategies for frequently accessed data
- Asynchronous processing for long-running tasks
- CDN integration for static assets

## Security Measures
- HTTPS for all communications
- JWT with short expiration times
- Rate limiting on API endpoints
- Input validation and sanitization
- Regular security audits
- OWASP best practices implementation

## Deployment Strategy
- Docker containers for consistent environments
- Self-hosted option with Docker Compose
- Cloud deployment options (AWS, GCP, Azure)
- Blue-green deployment for zero downtime updates
- Environment-specific configuration with Spring Profiles

import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  UserIcon,
  EnvelopeIcon,
  PhoneIcon,
  BuildingOfficeIcon,
  GlobeAltIcon,
  PencilIcon,
  CameraIcon
} from '@heroicons/react/24/outline';

// Profile Section Component
const ProfileSection = ({ title, children }) => {
  return (
    <div className="card-neumorphic mb-6">
      <h2 className="text-lg font-bold mb-4">{title}</h2>
      {children}
    </div>
  );
};

// Profile Field Component
const ProfileField = ({ label, value, icon: Icon }) => {
  return (
    <div className="flex items-center space-x-3 p-3 rounded-xl bg-secondary-50 mb-3">
      <div className="h-10 w-10 rounded-xl bg-white shadow-neumorphic flex items-center justify-center">
        <Icon className="h-5 w-5 text-secondary-600" />
      </div>
      <div className="flex-1">
        <p className="text-sm text-secondary-500">{label}</p>
        <p className="font-medium">{value}</p>
      </div>
    </div>
  );
};

// Social Account Component
const SocialAccount = ({ platform, username, connected }) => {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-secondary-50 mb-3">
      <div className="flex items-center space-x-3">
        <div className="h-10 w-10 rounded-xl bg-white p-2 shadow-neumorphic flex items-center justify-center">
          <img src={`/${platform.toLowerCase()}-icon.svg`} alt={platform} className="h-6 w-6" />
        </div>
        <div>
          <p className="font-medium">{platform}</p>
          {connected ? (
            <p className="text-sm text-secondary-500">@{username}</p>
          ) : (
            <p className="text-sm text-secondary-500">Not connected</p>
          )}
        </div>
      </div>
      <button className={`px-3 py-1 rounded-lg text-sm font-medium ${connected ? 'bg-secondary-200 text-secondary-800' : 'bg-primary-500 text-white'}`}>
        {connected ? 'Disconnect' : 'Connect'}
      </button>
    </div>
  );
};

// Stat Card Component
const StatCard = ({ title, value, description }) => {
  return (
    <div className="card-neumorphic text-center">
      <h3 className="text-secondary-500 font-medium mb-2">{title}</h3>
      <p className="text-3xl font-bold mb-1">{value}</p>
      <p className="text-sm text-secondary-500">{description}</p>
    </div>
  );
};

export default function Profile() {
  const [profile, setProfile] = useState({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    company: 'Acme Inc.',
    website: 'www.johndoe.com',
    bio: 'Digital marketing specialist with 5+ years of experience in social media management and content creation. Passionate about connecting brands with their audience through authentic storytelling.',
    socialAccounts: [
      { platform: 'Facebook', username: 'johndoe', connected: true },
      { platform: 'Instagram', username: 'johndoe', connected: true },
      { platform: 'WhatsApp', username: '+1 (555) 123-4567', connected: false }
    ],
    stats: {
      contacts: '1,234',
      conversations: '845',
      responseRate: '94%',
      avgResponseTime: '1.2h'
    }
  });

  return (
    <Layout title="My Profile">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ProfileSection title="Personal Information">
            <div className="flex items-center space-x-4 mb-6">
              <div className="relative">
                <div className="h-20 w-20 rounded-full bg-primary-100 flex items-center justify-center">
                  <span className="text-primary-700 text-2xl font-medium">
                    {profile.firstName.charAt(0)}{profile.lastName.charAt(0)}
                  </span>
                </div>
                <button className="absolute bottom-0 right-0 h-8 w-8 rounded-full bg-white shadow-neumorphic flex items-center justify-center">
                  <CameraIcon className="h-4 w-4 text-secondary-600" />
                </button>
              </div>
              <div>
                <h2 className="text-xl font-bold">{profile.firstName} {profile.lastName}</h2>
                <p className="text-secondary-500">Influencer</p>
              </div>
              <button className="button-secondary ml-auto flex items-center">
                <PencilIcon className="h-4 w-4 mr-2" />
                Edit Profile
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <ProfileField 
                label="First Name" 
                value={profile.firstName} 
                icon={UserIcon} 
              />
              <ProfileField 
                label="Last Name" 
                value={profile.lastName} 
                icon={UserIcon} 
              />
              <ProfileField 
                label="Email" 
                value={profile.email} 
                icon={EnvelopeIcon} 
              />
              <ProfileField 
                label="Phone" 
                value={profile.phone} 
                icon={PhoneIcon} 
              />
              <ProfileField 
                label="Company" 
                value={profile.company} 
                icon={BuildingOfficeIcon} 
              />
              <ProfileField 
                label="Website" 
                value={profile.website} 
                icon={GlobeAltIcon} 
              />
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Bio
              </label>
              <div className="p-3 rounded-xl bg-secondary-50">
                <p>{profile.bio}</p>
              </div>
            </div>
          </ProfileSection>
          
          <ProfileSection title="Connected Accounts">
            <div className="space-y-3">
              {profile.socialAccounts.map((account, index) => (
                <SocialAccount 
                  key={index}
                  platform={account.platform}
                  username={account.username}
                  connected={account.connected}
                />
              ))}
            </div>
          </ProfileSection>
        </div>
        
        <div>
          <ProfileSection title="Performance">
            <div className="grid grid-cols-2 gap-4 mb-6">
              <StatCard 
                title="Contacts" 
                value={profile.stats.contacts} 
                description="Total audience" 
              />
              <StatCard 
                title="Conversations" 
                value={profile.stats.conversations} 
                description="Total messages" 
              />
              <StatCard 
                title="Response Rate" 
                value={profile.stats.responseRate} 
                description="Messages answered" 
              />
              <StatCard 
                title="Response Time" 
                value={profile.stats.avgResponseTime} 
                description="Average time" 
              />
            </div>
          </ProfileSection>
          
          <ProfileSection title="Subscription">
            <div className="bg-primary-50 p-4 rounded-xl mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-lg font-bold text-primary-700">Pro Plan</span>
                <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                  Active
                </span>
              </div>
              <p className="text-sm text-secondary-600 mb-4">
                Your subscription renews on May 21, 2025
              </p>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Contacts:</span>
                  <span className="font-medium">1,234 / 5,000</span>
                </div>
                <div className="w-full bg-secondary-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '25%' }}></div>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span>Conversations:</span>
                  <span className="font-medium">845 / Unlimited</span>
                </div>
                
                <div className="flex justify-between text-sm">
                  <span>Flows:</span>
                  <span className="font-medium">3 / 10</span>
                </div>
                <div className="w-full bg-secondary-200 rounded-full h-2">
                  <div className="bg-primary-500 h-2 rounded-full" style={{ width: '30%' }}></div>
                </div>
              </div>
            </div>
            <button className="button-primary w-full">Upgrade Plan</button>
          </ProfileSection>
        </div>
      </div>
    </Layout>
  );
}

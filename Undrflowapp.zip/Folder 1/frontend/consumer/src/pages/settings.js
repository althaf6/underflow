import React, { useState } from 'react';
import Layout from '../components/Layout';
import { motion } from 'framer-motion';
import { useSpring, animated } from 'react-spring';
import { 
  UserIcon,
  BellIcon,
  LockClosedIcon,
  CreditCardIcon,
  GlobeAltIcon,
  DocumentTextIcon,
  Cog6ToothIcon,
  ArrowPathIcon,
  ShieldCheckIcon,
  DevicePhoneMobileIcon
} from '@heroicons/react/24/outline';

// Settings Tab Component
const SettingsTab = ({ icon: Icon, title, active, onClick }) => {
  const springProps = useSpring({
    backgroundColor: active ? 'rgba(239, 246, 255, 1)' : 'rgba(255, 255, 255, 0)',
    color: active ? 'rgb(29, 78, 216)' : 'rgb(71, 85, 105)',
    config: { tension: 300, friction: 20 }
  });

  return (
    <animated.button
      onClick={onClick}
      style={springProps}
      className="flex items-center space-x-3 w-full text-left px-4 py-3 rounded-xl transition-all duration-300"
    >
      <Icon className="h-5 w-5" />
      <span>{title}</span>
    </animated.button>
  );
};

// Toggle Switch Component
const ToggleSwitch = ({ enabled, onChange }) => {
  const springProps = useSpring({
    transform: enabled ? 'translateX(100%)' : 'translateX(0%)',
    backgroundColor: enabled ? 'rgb(14, 165, 233)' : 'rgb(226, 232, 240)',
    config: { tension: 300, friction: 20 }
  });

  return (
    <div 
      onClick={() => onChange(!enabled)} 
      className="relative w-11 h-6 bg-secondary-200 rounded-full cursor-pointer"
    >
      <animated.div 
        style={springProps}
        className="absolute top-[2px] left-[2px] w-5 h-5 bg-white rounded-full shadow-md"
      />
    </div>
  );
};

// Profile Settings Component
const ProfileSettings = () => {
  const [formData, setFormData] = useState({
    firstName: 'John',
    lastName: 'Doe',
    email: 'john.doe@example.com',
    phone: '+1 (555) 123-4567',
    company: 'Acme Inc.',
    website: 'www.johndoe.com'
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold mb-6">Profile Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <div className="flex items-center space-x-4 mb-6">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative"
          >
            <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center">
              <span className="text-primary-700 text-xl font-medium">JD</span>
            </div>
            <div className="absolute bottom-0 right-0 h-6 w-6 rounded-full bg-white shadow-neumorphic flex items-center justify-center cursor-pointer">
              <DevicePhoneMobileIcon className="h-3 w-3 text-secondary-600" />
            </div>
          </motion.div>
          <div>
            <h3 className="font-medium">{formData.firstName} {formData.lastName}</h3>
            <p className="text-sm text-secondary-500">{formData.email}</p>
          </div>
          <motion.button 
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="button-secondary ml-auto"
          >
            Change Avatar
          </motion.button>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                First Name
              </label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleChange}
                className="input-neumorphic w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Last Name
              </label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleChange}
                className="input-neumorphic w-full"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Phone
            </label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Company
            </label>
            <input
              type="text"
              name="company"
              value={formData.company}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Website
            </label>
            <input
              type="text"
              name="website"
              value={formData.website}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <motion.button 
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="button-primary"
        >
          Save Changes
        </motion.button>
      </div>
    </motion.div>
  );
};

// Security Settings Component
const SecuritySettings = () => {
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  const handleChange = (e) => {
    setPasswordData({
      ...passwordData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold mb-6">Security Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Change Password</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Current Password
            </label>
            <input
              type="password"
              name="currentPassword"
              value={passwordData.currentPassword}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              New Password
            </label>
            <input
              type="password"
              name="newPassword"
              value={passwordData.newPassword}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={passwordData.confirmPassword}
              onChange={handleChange}
              className="input-neumorphic w-full"
            />
          </div>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Two-Factor Authentication</h3>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-secondary-700">Protect your account with 2FA</p>
            <p className="text-sm text-secondary-500">{twoFactorEnabled ? 'Currently enabled' : 'Currently disabled'}</p>
          </div>
          <ToggleSwitch enabled={twoFactorEnabled} onChange={setTwoFactorEnabled} />
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Session Management</h3>
        <div className="bg-secondary-50 p-3 rounded-xl mb-4">
          <div className="flex justify-between mb-2">
            <span className="text-secondary-500">Current Session:</span>
            <div className="flex items-center">
              <span className="text-sm">Chrome on macOS</span>
              <span className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                Active
              </span>
            </div>
          </div>
          <div className="flex justify-between">
            <span className="text-secondary-500">Last activity:</span>
            <span>Just now</span>
          </div>
        </div>
        <div className="flex justify-end">
          <motion.button 
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="button-secondary flex items-center"
          >
            <ArrowPathIcon className="h-5 w-5 mr-2" />
            Log Out All Devices
          </motion.button>
        </div>
      </div>
      
      <div className="flex justify-end">
        <motion.button 
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="button-primary"
        >
          Save Changes
        </motion.button>
      </div>
    </motion.div>
  );
};

// Notification Settings Component
const NotificationSettings = () => {
  const [notifications, setNotifications] = useState({
    newContact: true,
    flowCompletion: true,
    subscriptionUpdates: false,
    marketingUpdates: true,
    realTimeAlerts: true,
    soundAlerts: false
  });

  const handleToggle = (key) => {
    setNotifications({
      ...notifications,
      [key]: !notifications[key]
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold mb-6">Notification Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Email Notifications</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">New Contact Notifications</p>
              <p className="text-sm text-secondary-500">Get notified when a new contact is added</p>
            </div>
            <ToggleSwitch enabled={notifications.newContact} onChange={() => handleToggle('newContact')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Flow Completion Alerts</p>
              <p className="text-sm text-secondary-500">Get notified when a flow is completed</p>
            </div>
            <ToggleSwitch enabled={notifications.flowCompletion} onChange={() => handleToggle('flowCompletion')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Subscription Updates</p>
              <p className="text-sm text-secondary-500">Get notified about subscription changes</p>
            </div>
            <ToggleSwitch enabled={notifications.subscriptionUpdates} onChange={() => handleToggle('subscriptionUpdates')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Marketing Updates</p>
              <p className="text-sm text-secondary-500">Receive marketing and feature updates</p>
            </div>
            <ToggleSwitch enabled={notifications.marketingUpdates} onChange={() => handleToggle('marketingUpdates')} />
          </div>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">In-App Notifications</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Real-time Alerts</p>
              <p className="text-sm text-secondary-500">Show real-time notifications in the dashboard</p>
            </div>
            <ToggleSwitch enabled={notifications.realTimeAlerts} onChange={() => handleToggle('realTimeAlerts')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Sound Alerts</p>
              <p className="text-sm text-secondary-500">Play sound when notifications arrive</p>
            </div>
            <ToggleSwitch enabled={notifications.soundAlerts} onChange={() => handleToggle('soundAlerts')} />
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <motion.button 
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="button-primary"
        >
          Save Changes
        </motion.button>
      </div>
    </motion.div>
  );
};

// Billing Settings Component
const BillingSettings = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold mb-6">Billing Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Current Plan</h3>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-primary-50 p-4 rounded-xl mb-4"
        >
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-lg font-bold text-primary-700">Pro Plan</span>
              <span className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                Active
              </span>
            </div>
            <span className="text-xl font-bold">$29<span className="text-sm font-normal">/month</span></span>
          </div>
          <p className="text-sm text-secondary-600 mb-2">
            Your plan renews on May 21, 2025
          </p>
          <div className="flex space-x-3">
            <motion.button 
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="button-secondary text-sm"
            >
              Change Plan
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="text-sm text-danger-500 hover:text-danger-700"
            >
              Cancel Subscription
            </motion.button>
          </div>
        </motion.div>
        
        <h3 className="font-medium mb-4">Payment Method</h3>
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-secondary-50 p-4 rounded-xl mb-4"
        >
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-lg bg-white p-2 shadow-neumorphic flex items-center justify-center">
              <CreditCardIcon className="h-6 w-6 text-secondary-700" />
            </div>
            <div>
              <p className="font-medium">Visa ending in 4242</p>
              <p className="text-sm text-secondary-500">Expires 12/2026</p>
            </div>
            <motion.button 
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="button-secondary text-sm ml-auto"
            >
              Update
            </motion.button>
          </div>
        </motion.div>
        
        <h3 className="font-medium mb-4">Billing History</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-secondary-100">
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Date</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Description</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Amount</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Status</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Invoice</th>
              </tr>
            </thead>
            <tbody>
              <motion.tr 
                whileHover={{ backgroundColor: 'rgba(241, 245, 249, 0.5)' }}
                className="border-b border-secondary-100"
              >
                <td className="py-3 px-4 text-sm">Apr 21, 2025</td>
                <td className="py-3 px-4 text-sm">Pro Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$29.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </motion.tr>
              <motion.tr 
                whileHover={{ backgroundColor: 'rgba(241, 245, 249, 0.5)' }}
                className="border-b border-secondary-100"
              >
                <td className="py-3 px-4 text-sm">Mar 21, 2025</td>
                <td className="py-3 px-4 text-sm">Pro Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$29.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </motion.tr>
              <motion.tr 
                whileHover={{ backgroundColor: 'rgba(241, 245, 249, 0.5)' }}
              >
                <td className="py-3 px-4 text-sm">Feb 21, 2025</td>
                <td className="py-3 px-4 text-sm">Pro Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$29.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </motion.tr>
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
};

// Privacy Settings Component
const PrivacySettings = () => {
  const [privacySettings, setPrivacySettings] = useState({
    dataSharing: true,
    activityTracking: true,
    cookieUsage: true,
    marketingConsent: false
  });

  const handleToggle = (key) => {
    setPrivacySettings({
      ...privacySettings,
      [key]: !privacySettings[key]
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <h2 className="text-xl font-bold mb-6">Privacy Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <div className="flex items-center mb-6">
          <div className="h-10 w-10 rounded-xl bg-primary-50 flex items-center justify-center mr-4">
            <ShieldCheckIcon className="h-6 w-6 text-primary-500" />
          </div>
          <div>
            <h3 className="font-medium">Data Privacy Controls</h3>
            <p className="text-sm text-secondary-500">Manage how your data is used and shared</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Data Sharing</p>
              <p className="text-sm text-secondary-500">Allow sharing of anonymized data for service improvement</p>
            </div>
            <ToggleSwitch enabled={privacySettings.dataSharing} onChange={() => handleToggle('dataSharing')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Activity Tracking</p>
              <p className="text-sm text-secondary-500">Track your activity to personalize your experience</p>
            </div>
            <ToggleSwitch enabled={privacySettings.activityTracking} onChange={() => handleToggle('activityTracking')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Cookie Usage</p>
              <p className="text-sm text-secondary-500">Allow cookies to enhance your browsing experience</p>
            </div>
            <ToggleSwitch enabled={privacySettings.cookieUsage} onChange={() => handleToggle('cookieUsage')} />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Marketing Consent</p>
              <p className="text-sm text-secondary-500">Receive personalized marketing communications</p>
            </div>
            <ToggleSwitch enabled={privacySettings.marketingConsent} onChange={() => handleToggle('marketingConsent')} />
          </div>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Data Management</h3>
        <div className="space-y-4">
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full p-3 rounded-xl bg-secondary-50 text-left flex justify-between items-center"
          >
            <div>
              <p className="font-medium">Download Your Data</p>
              <p className="text-sm text-secondary-500">Get a copy of all your personal data</p>
            </div>
            <ArrowPathIcon className="h-5 w-5 text-secondary-500" />
          </motion.button>
          
          <motion.button 
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full p-3 rounded-xl bg-secondary-50 text-left flex justify-between items-center"
          >
            <div>
              <p className="font-medium text-danger-600">Delete Account</p>
              <p className="text-sm text-secondary-500">Permanently delete your account and all data</p>
            </div>
            <ArrowPathIcon className="h-5 w-5 text-danger-500" />
          </motion.button>
        </div>
      </div>
      
      <div className="flex justify-end">
        <motion.button 
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="button-primary"
        >
          Save Changes
        </motion.button>
      </div>
    </motion.div>
  );
};

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'notifications':
        return <NotificationSettings />;
      case 'billing':
        return <BillingSettings />;
      case 'privacy':
        return <PrivacySettings />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <Layout title="Settings">
      <div className="flex flex-col md:flex-row gap-6">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
          className="md:w-64 space-y-2"
        >
          <SettingsTab 
            icon={UserIcon} 
            title="Profile" 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')} 
          />
          <SettingsTab 
            icon={LockClosedIcon} 
            title="Security" 
            active={activeTab === 'security'} 
            onClick={() => setActiveTab('security')} 
          />
          <SettingsTab 
            icon={BellIcon} 
            title="Notifications" 
            active={activeTab === 'notifications'} 
            onClick={() => setActiveTab('notifications')} 
          />
          <SettingsTab 
            icon={CreditCardIcon} 
            title="Billing" 
            active={activeTab === 'billing'} 
            onClick={() => setActiveTab('billing')} 
          />
          <SettingsTab 
            icon={ShieldCheckIcon} 
            title="Privacy" 
            active={activeTab === 'privacy'} 
            onClick={() => setActiveTab('privacy')} 
          />
        </motion.div>
        <div className="flex-1">
          {renderTabContent()}
        </div>
      </div>
    </Layout>
  );
}

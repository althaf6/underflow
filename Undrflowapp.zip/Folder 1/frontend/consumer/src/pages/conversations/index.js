import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  ChatBubbleLeftRightIcon,
  MagnifyingGlassIcon,
  PlusIcon
} from '@heroicons/react/24/outline';

// Conversation Card Component
const ConversationCard = ({ conversation, onClick }) => {
  return (
    <div 
      onClick={() => onClick(conversation.id)}
      className="flex items-center space-x-3 p-4 rounded-xl bg-white shadow-neumorphic mb-3 cursor-pointer hover:shadow-none transition-all duration-300"
    >
      <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center">
        <span className="text-primary-700 font-medium">{conversation.name.charAt(0)}</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center">
          <p className="font-medium truncate">{conversation.name}</p>
          <p className="text-xs text-secondary-500">{conversation.time}</p>
        </div>
        <p className="text-sm text-secondary-500 truncate">{conversation.lastMessage}</p>
      </div>
      {conversation.unread > 0 && (
        <div className="h-5 w-5 rounded-full bg-primary-500 text-white text-xs flex items-center justify-center">
          {conversation.unread}
        </div>
      )}
    </div>
  );
};

export default function Conversations() {
  const [conversations, setConversations] = useState([
    {
      id: 1,
      name: 'Sarah Johnson',
      lastMessage: 'Thanks for the information!',
      time: '2m ago',
      unread: 0,
      platform: 'facebook'
    },
    {
      id: 2,
      name: 'Michael Brown',
      lastMessage: 'When will the new products be available?',
      time: '15m ago',
      unread: 2,
      platform: 'facebook'
    },
    {
      id: 3,
      name: 'Emily Davis',
      lastMessage: 'I'd like to schedule a consultation.',
      time: '1h ago',
      unread: 0,
      platform: 'instagram'
    },
    {
      id: 4,
      name: 'David Wilson',
      lastMessage: 'Do you offer international shipping?',
      time: '3h ago',
      unread: 1,
      platform: 'whatsapp'
    },
    {
      id: 5,
      name: 'Jennifer Taylor',
      lastMessage: 'I love your new collection!',
      time: '5h ago',
      unread: 0,
      platform: 'facebook'
    }
  ]);
  
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleConversationClick = (conversationId) => {
    // In a real app, this would navigate to the conversation
    window.location.href = `/conversations/${conversationId}`;
  };
  
  const filteredConversations = conversations.filter(conversation => {
    // Filter by platform
    if (activeFilter !== 'all' && conversation.platform !== activeFilter) {
      return false;
    }
    
    // Filter by search query
    if (searchQuery && !conversation.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });

  return (
    <Layout title="Conversations">
      <div className="card-neumorphic mb-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-secondary-400" />
            </div>
            <input
              type="text"
              className="input-neumorphic pl-10 pr-4 py-2 w-full md:w-64"
              placeholder="Search conversations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex space-x-2">
            <button 
              onClick={() => setActiveFilter('all')}
              className={`px-4 py-2 rounded-xl text-sm font-medium ${
                activeFilter === 'all' 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-secondary-100 text-secondary-800 hover:bg-secondary-200'
              }`}
            >
              All
            </button>
            <button 
              onClick={() => setActiveFilter('facebook')}
              className={`px-4 py-2 rounded-xl text-sm font-medium ${
                activeFilter === 'facebook' 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-secondary-100 text-secondary-800 hover:bg-secondary-200'
              }`}
            >
              Facebook
            </button>
            <button 
              onClick={() => setActiveFilter('instagram')}
              className={`px-4 py-2 rounded-xl text-sm font-medium ${
                activeFilter === 'instagram' 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-secondary-100 text-secondary-800 hover:bg-secondary-200'
              }`}
            >
              Instagram
            </button>
            <button 
              onClick={() => setActiveFilter('whatsapp')}
              className={`px-4 py-2 rounded-xl text-sm font-medium ${
                activeFilter === 'whatsapp' 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-secondary-100 text-secondary-800 hover:bg-secondary-200'
              }`}
            >
              WhatsApp
            </button>
          </div>
        </div>
        
        <div className="space-y-3">
          {filteredConversations.length > 0 ? (
            filteredConversations.map(conversation => (
              <ConversationCard 
                key={conversation.id} 
                conversation={conversation} 
                onClick={handleConversationClick}
              />
            ))
          ) : (
            <div className="text-center py-8">
              <ChatBubbleLeftRightIcon className="h-12 w-12 text-secondary-300 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-secondary-700">No conversations found</h3>
              <p className="text-secondary-500">Try adjusting your filters or search query</p>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

import React, { useState, useRef, useEffect } from 'react';
import Layout from '../components/Layout';
import { 
  PaperAirplaneIcon, 
  MicrophoneIcon,
  PhotoIcon,
  FaceSmileIcon,
  PaperClipIcon,
  EllipsisHorizontalIcon
} from '@heroicons/react/24/outline';

// Contact Info Component
const ContactInfo = ({ contact, onClose }) => {
  return (
    <div className="card-neumorphic h-full">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-bold">Contact Info</h2>
        <button onClick={onClose} className="text-secondary-500 hover:text-secondary-700">
          <EllipsisHorizontalIcon className="h-6 w-6" />
        </button>
      </div>
      
      <div className="flex flex-col items-center mb-6">
        <div className="h-20 w-20 rounded-full bg-primary-100 flex items-center justify-center mb-3">
          <span className="text-primary-700 text-2xl font-medium">
            {contact.firstName.charAt(0)}{contact.lastName.charAt(0)}
          </span>
        </div>
        <h3 className="text-xl font-bold">{contact.firstName} {contact.lastName}</h3>
        <p className="text-secondary-500">{contact.source}</p>
      </div>
      
      <div className="space-y-4">
        <div>
          <h4 className="text-sm font-medium text-secondary-500 mb-1">Email</h4>
          <p>{contact.email}</p>
        </div>
        
        {contact.phone && (
          <div>
            <h4 className="text-sm font-medium text-secondary-500 mb-1">Phone</h4>
            <p>{contact.phone}</p>
          </div>
        )}
        
        <div>
          <h4 className="text-sm font-medium text-secondary-500 mb-1">Tags</h4>
          <div className="flex flex-wrap gap-2">
            {contact.tags.map((tag, index) => (
              <span 
                key={index} 
                className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-sm font-medium text-secondary-500 mb-1">Conversation History</h4>
          <div className="bg-secondary-50 p-3 rounded-xl">
            <div className="flex justify-between text-sm mb-2">
              <span>First conversation:</span>
              <span className="font-medium">{contact.firstConversation}</span>
            </div>
            <div className="flex justify-between text-sm mb-2">
              <span>Total conversations:</span>
              <span className="font-medium">{contact.totalConversations}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Response rate:</span>
              <span className="font-medium">{contact.responseRate}</span>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-6 border-t border-secondary-100">
        <button className="button-primary w-full">Edit Contact</button>
      </div>
    </div>
  );
};

// Message Component
const Message = ({ message }) => {
  return (
    <div className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
      {message.sender !== 'user' && (
        <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center mr-2">
          <span className="text-primary-700 font-medium text-xs">SJ</span>
        </div>
      )}
      <div className={`chat-bubble ${message.sender === 'user' ? 'chat-bubble-user' : 'chat-bubble-bot'}`}>
        <p>{message.text}</p>
        <p className="text-xs opacity-70 text-right mt-1">{message.time}</p>
      </div>
    </div>
  );
};

export default function Conversation() {
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'contact',
      text: 'Hi there! I'm interested in your new product line. Can you tell me more about it?',
      time: '10:30 AM'
    },
    {
      id: 2,
      sender: 'user',
      text: 'Hello Sarah! Of course, I'd be happy to tell you about our new products. We just launched a new collection of eco-friendly items that are both sustainable and stylish.',
      time: '10:32 AM'
    },
    {
      id: 3,
      sender: 'contact',
      text: 'That sounds great! What kind of materials do you use?',
      time: '10:33 AM'
    },
    {
      id: 4,
      sender: 'user',
      text: 'We use recycled plastics, organic cotton, and bamboo. All of our packaging is also biodegradable.',
      time: '10:35 AM'
    },
    {
      id: 5,
      sender: 'contact',
      text: 'Perfect! I'm really trying to reduce my environmental footprint. Do you have a catalog I could look at?',
      time: '10:36 AM'
    },
    {
      id: 6,
      sender: 'user',
      text: 'Absolutely! I can send you our digital catalog right away. It has all the details about our new collection, including prices and materials used.',
      time: '10:38 AM'
    },
    {
      id: 7,
      sender: 'contact',
      text: 'Thanks for the information!',
      time: '10:40 AM'
    }
  ]);
  
  const [inputMessage, setInputMessage] = useState('');
  const messagesEndRef = useRef(null);
  
  const contact = {
    firstName: 'Sarah',
    lastName: 'Johnson',
    email: 'sarah.johnson@example.com',
    phone: '+1 (555) 123-4567',
    source: 'Facebook',
    tags: ['Interested', 'Eco-friendly'],
    firstConversation: 'Apr 15, 2025',
    totalConversations: '3',
    responseRate: '95%'
  };
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [messages]);
  
  const handleSendMessage = () => {
    if (inputMessage.trim() === '') return;
    
    const newMessage = {
      id: messages.length + 1,
      sender: 'user',
      text: inputMessage,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setMessages([...messages, newMessage]);
    setInputMessage('');
  };
  
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-8rem)]">
        <div className="lg:col-span-3 flex flex-col card-neumorphic h-full">
          <div className="flex justify-between items-center p-4 border-b border-secondary-100">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
                <span className="text-primary-700 font-medium">SJ</span>
              </div>
              <div>
                <h2 className="font-medium">{contact.firstName} {contact.lastName}</h2>
                <div className="flex items-center text-sm text-secondary-500">
                  <span className="h-2 w-2 rounded-full bg-success-500 mr-1"></span>
                  <span>Online</span>
                </div>
              </div>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={() => setShowContactInfo(!showContactInfo)}
                className="p-2 rounded-full hover:bg-secondary-100"
              >
                <EllipsisHorizontalIcon className="h-5 w-5 text-secondary-500" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map(message => (
              <Message key={message.id} message={message} />
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-4 border-t border-secondary-100">
            <div className="flex items-center space-x-2">
              <button className="p-2 rounded-full hover:bg-secondary-100">
                <PaperClipIcon className="h-5 w-5 text-secondary-500" />
              </button>
              <button className="p-2 rounded-full hover:bg-secondary-100">
                <PhotoIcon className="h-5 w-5 text-secondary-500" />
              </button>
              <div className="flex-1 relative">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="chat-input w-full pr-10"
                  placeholder="Type a message..."
                  rows="1"
                ></textarea>
                <button className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-full hover:bg-secondary-100">
                  <FaceSmileIcon className="h-5 w-5 text-secondary-500" />
                </button>
              </div>
              <button 
                onClick={handleSendMessage}
                className="p-3 rounded-full bg-primary-500 text-white hover:bg-primary-600"
              >
                <PaperAirplaneIcon className="h-5 w-5" />
              </button>
            </div>
          </div>
        </div>
        
        {showContactInfo && (
          <div className="hidden lg:block">
            <ContactInfo contact={contact} onClose={() => setShowContactInfo(false)} />
          </div>
        )}
      </div>
    </Layout>
  );
}

import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  ArrowTrendingUpIcon, 
  ChatBubbleLeftRightIcon,
  EnvelopeIcon,
  UserGroupIcon,
  CalendarIcon
} from '@heroicons/react/24/outline';

// Stat Card Component
const StatCard = ({ title, value, icon: Icon, change, changeType }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-secondary-500 font-medium">{title}</h3>
        <div className="h-10 w-10 rounded-xl bg-primary-50 flex items-center justify-center">
          <Icon className="h-6 w-6 text-primary-500" />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <p className="text-3xl font-bold">{value}</p>
        {change && (
          <p className={`flex items-center text-sm ${changeType === 'increase' ? 'text-success-500' : 'text-danger-500'}`}>
            <ArrowTrendingUpIcon className={`h-4 w-4 mr-1 ${changeType === 'decrease' && 'transform rotate-180'}`} />
            {change}
          </p>
        )}
      </div>
    </div>
  );
};

// Recent Conversation Component
const RecentConversation = ({ conversation, onClick }) => {
  return (
    <div 
      onClick={() => onClick(conversation.id)}
      className="flex items-center space-x-3 p-3 rounded-xl bg-white shadow-neumorphic mb-3 cursor-pointer hover:shadow-none transition-all duration-300"
    >
      <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
        <span className="text-primary-700 font-medium">{conversation.name.charAt(0)}</span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex justify-between items-center">
          <p className="font-medium truncate">{conversation.name}</p>
          <p className="text-xs text-secondary-500">{conversation.time}</p>
        </div>
        <p className="text-sm text-secondary-500 truncate">{conversation.lastMessage}</p>
      </div>
      {conversation.unread > 0 && (
        <div className="h-5 w-5 rounded-full bg-primary-500 text-white text-xs flex items-center justify-center">
          {conversation.unread}
        </div>
      )}
    </div>
  );
};

// Channel Card Component
const ChannelCard = ({ channel, onConnect }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center space-x-3 mb-4">
        <div className="h-10 w-10 rounded-xl bg-white p-2 shadow-neumorphic flex items-center justify-center">
          <img src={`/${channel.type}-icon.svg`} alt={channel.type} className="h-6 w-6" />
        </div>
        <div>
          <h3 className="font-medium">{channel.name}</h3>
          <div className="flex items-center text-sm text-secondary-500">
            <span className={`h-2 w-2 rounded-full ${channel.connected ? 'bg-success-500' : 'bg-secondary-400'} mr-1`}></span>
            <span>{channel.connected ? 'Connected' : 'Not Connected'}</span>
          </div>
        </div>
      </div>
      
      {channel.connected ? (
        <div className="bg-secondary-50 p-3 rounded-xl">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-secondary-500">Page:</span>
            <span className="font-medium">{channel.pageName}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-secondary-500">Audience:</span>
            <span className="font-medium">{channel.audience}</span>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => onConnect(channel.type)} 
          className="button-primary w-full"
        >
          Connect {channel.name}
        </button>
      )}
    </div>
  );
};

export default function Dashboard() {
  const [conversations, setConversations] = useState([
    {
      id: 1,
      name: 'Sarah Johnson',
      lastMessage: 'Thanks for the information!',
      time: '2m ago',
      unread: 0
    },
    {
      id: 2,
      name: 'Michael Brown',
      lastMessage: 'When will the new products be available?',
      time: '15m ago',
      unread: 2
    },
    {
      id: 3,
      name: 'Emily Davis',
      lastMessage: 'I'd like to schedule a consultation.',
      time: '1h ago',
      unread: 0
    }
  ]);
  
  const [channels, setChannels] = useState([
    {
      type: 'facebook',
      name: 'Facebook Messenger',
      connected: true,
      pageName: 'My Business Page',
      audience: '1,234 people'
    },
    {
      type: 'instagram',
      name: 'Instagram Direct',
      connected: false
    },
    {
      type: 'whatsapp',
      name: 'WhatsApp Business',
      connected: false
    }
  ]);
  
  const handleConversationClick = (conversationId) => {
    // In a real app, this would navigate to the conversation
    console.log(`Open conversation ${conversationId}`);
  };
  
  const handleConnectChannel = (channelType) => {
    // In a real app, this would open the connection flow
    console.log(`Connect ${channelType}`);
  };

  return (
    <Layout title="Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatCard 
          title="Total Contacts" 
          value="1,234" 
          icon={UserGroupIcon} 
          change="12%" 
          changeType="increase" 
        />
        <StatCard 
          title="Active Conversations" 
          value="28" 
          icon={ChatBubbleLeftRightIcon} 
          change="8%" 
          changeType="increase" 
        />
        <StatCard 
          title="Messages Sent" 
          value="845" 
          icon={EnvelopeIcon} 
          change="5%" 
          changeType="increase" 
        />
        <StatCard 
          title="Response Rate" 
          value="94%" 
          icon={ArrowTrendingUpIcon} 
          change="3%" 
          changeType="increase" 
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="card-neumorphic">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">Recent Conversations</h2>
              <button className="text-primary-500 text-sm">View All</button>
            </div>
            
            <div className="space-y-3">
              {conversations.map(conversation => (
                <RecentConversation 
                  key={conversation.id} 
                  conversation={conversation} 
                  onClick={handleConversationClick}
                />
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-secondary-100">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">Upcoming Events</h3>
                  <p className="text-sm text-secondary-500">You have 2 scheduled events</p>
                </div>
                <button className="button-secondary text-sm flex items-center">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  View Calendar
                </button>
              </div>
              
              <div className="mt-3 space-y-3">
                <div className="p-3 rounded-xl bg-secondary-50">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Product Launch Broadcast</p>
                      <p className="text-sm text-secondary-500">Tomorrow, 2:00 PM</p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                      Scheduled
                    </span>
                  </div>
                </div>
                
                <div className="p-3 rounded-xl bg-secondary-50">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Q&A Session</p>
                      <p className="text-sm text-secondary-500">Friday, 4:00 PM</p>
                    </div>
                    <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                      Scheduled
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <div className="card-neumorphic mb-6">
            <h2 className="text-lg font-bold mb-4">Your Channels</h2>
            <div className="space-y-4">
              {channels.map(channel => (
                <ChannelCard 
                  key={channel.type} 
                  channel={channel} 
                  onConnect={handleConnectChannel}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

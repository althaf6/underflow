import React from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { 
  HomeIcon, 
  ChatBubbleLeftRightIcon, 
  UserIcon,
  Cog6ToothIcon,
  BellIcon,
  ArrowRightOnRectangleIcon
} from '@heroicons/react/24/outline';

const Navbar = ({ active }) => {
  const router = useRouter();
  
  const menuItems = [
    { name: 'Dashboard', icon: HomeIcon, href: '/dashboard' },
    { name: 'Conversations', icon: ChatBubbleLeftRightIcon, href: '/conversations' },
    { name: 'Profile', icon: UserIcon, href: '/profile' },
    { name: 'Settings', icon: Cog6ToothIcon, href: '/settings' },
  ];

  return (
    <div className="bg-white border-b border-secondary-100 px-4 py-2 flex justify-between items-center">
      <div className="flex items-center">
        <h1 className="text-xl font-bold text-primary-600 mr-8">Undrflow</h1>
        
        <nav className="hidden md:flex space-x-1">
          {menuItems.map((item) => (
            <Link 
              href={item.href} 
              key={item.name}
              className={`nav-item ${router.pathname === item.href ? 'active' : ''}`}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.name}</span>
            </Link>
          ))}
        </nav>
      </div>
      
      <div className="flex items-center space-x-3">
        <button className="relative p-2 rounded-full bg-white shadow-neumorphic">
          <BellIcon className="h-5 w-5 text-secondary-600" />
          <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-primary-500"></span>
        </button>
        
        <div className="flex items-center space-x-3 p-2 rounded-xl">
          <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
            <span className="text-primary-700 font-medium text-sm">JD</span>
          </div>
          <div className="hidden md:block">
            <p className="text-sm font-medium">John Doe</p>
            <p className="text-xs text-secondary-500">Influencer</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;

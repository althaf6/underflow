import React from 'react';
import Navbar from '../components/Navbar';

const Layout = ({ children, title }) => {
  return (
    <div className="min-h-screen bg-secondary-50">
      <Navbar />
      <main className="container mx-auto px-4 py-6">
        {title && (
          <h1 className="text-2xl font-bold text-secondary-900 mb-6">{title}</h1>
        )}
        {children}
      </main>
    </div>
  );
};

export default Layout;

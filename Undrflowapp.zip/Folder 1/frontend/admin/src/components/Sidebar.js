import React from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import { 
  HomeIcon, 
  UsersIcon, 
  ChatBubbleLeftRightIcon, 
  UserGroupIcon,
  ChartBarIcon,
  Cog6ToothIcon,
  BellIcon,
  ArrowRightOnRectangleIcon
} from '@heroicons/react/24/outline';

const Sidebar = ({ active }) => {
  const router = useRouter();
  
  const menuItems = [
    { name: 'Dashboard', icon: HomeIcon, href: '/dashboard' },
    { name: 'Users', icon: UsersIcon, href: '/users' },
    { name: 'Contacts', icon: UserGroupIcon, href: '/contacts' },
    { name: 'Flows', icon: ChatBubbleLeftRightIcon, href: '/flows' },
    { name: 'Analytics', icon: ChartBarIcon, href: '/analytics' },
    { name: 'Settings', icon: Cog6ToothIcon, href: '/settings' },
  ];

  return (
    <div className="h-screen w-64 bg-white border-r border-secondary-100 flex flex-col">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-primary-600">Undrflow</h1>
      </div>
      
      <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => (
          <Link 
            href={item.href} 
            key={item.name}
            className={`sidebar-item ${router.pathname === item.href ? 'active' : ''}`}
          >
            <item.icon className="h-5 w-5" />
            <span>{item.name}</span>
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-secondary-100">
        <div className="flex items-center space-x-3 p-3 rounded-xl bg-secondary-50">
          <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
            <span className="text-primary-700 font-medium">JD</span>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">John Doe</p>
            <p className="text-xs text-secondary-500">Admin</p>
          </div>
          <button className="text-secondary-400 hover:text-secondary-600">
            <ArrowRightOnRectangleIcon className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;

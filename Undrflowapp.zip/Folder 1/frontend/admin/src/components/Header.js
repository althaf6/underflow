import React from 'react';
import { BellIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline';

const Header = ({ title, subtitle }) => {
  return (
    <div className="bg-white border-b border-secondary-100 py-4 px-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-secondary-900">{title}</h1>
          {subtitle && <p className="text-sm text-secondary-500">{subtitle}</p>}
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-secondary-400" />
            </div>
            <input
              type="text"
              className="input-neumorphic pl-10 pr-4 py-2 w-64"
              placeholder="Search..."
            />
          </div>
          
          <button className="relative p-2 rounded-full bg-white shadow-neumorphic">
            <BellIcon className="h-5 w-5 text-secondary-600" />
            <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-primary-500"></span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Header;

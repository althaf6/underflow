import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  PlusIcon,
  ArrowPathIcon,
  PlayIcon,
  PauseIcon,
  TrashIcon,
  PencilIcon,
  DocumentDuplicateIcon
} from '@heroicons/react/24/outline';

// Flow Card Component
const FlowCard = ({ flow, onEdit, onDuplicate, onDelete, onToggleStatus }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'ACTIVE':
        return 'bg-success-500';
      case 'PAUSED':
        return 'bg-warning-500';
      case 'DRAFT':
        return 'bg-secondary-400';
      case 'ARCHIVED':
        return 'bg-danger-500';
      default:
        return 'bg-secondary-400';
    }
  };

  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium">{flow.name}</h3>
        <div className="flex items-center space-x-2">
          <span className={`h-2 w-2 rounded-full ${getStatusColor(flow.status)}`}></span>
          <span className="text-sm text-secondary-500 capitalize">{flow.status.toLowerCase()}</span>
        </div>
      </div>
      
      {flow.description && (
        <p className="text-sm text-secondary-600 mb-4">{flow.description}</p>
      )}
      
      <div className="bg-secondary-50 p-3 rounded-xl mb-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-secondary-500">Triggers:</span>
          <span className="font-medium">{flow.triggers.join(', ')}</span>
        </div>
        <div className="flex justify-between text-sm mb-2">
          <span className="text-secondary-500">Created:</span>
          <span className="font-medium">{flow.createdAt}</span>
        </div>
        {flow.statistics && (
          <>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-secondary-500">Started:</span>
              <span className="font-medium">{flow.statistics.started}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-secondary-500">Completed:</span>
              <span className="font-medium">{flow.statistics.completed}</span>
            </div>
          </>
        )}
      </div>
      
      <div className="flex justify-between">
        <div className="flex space-x-2">
          <button 
            onClick={() => onEdit(flow.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
            title="Edit Flow"
          >
            <PencilIcon className="h-4 w-4 text-secondary-500" />
          </button>
          <button 
            onClick={() => onDuplicate(flow.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
            title="Duplicate Flow"
          >
            <DocumentDuplicateIcon className="h-4 w-4 text-secondary-500" />
          </button>
          <button 
            onClick={() => onDelete(flow.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
            title="Delete Flow"
          >
            <TrashIcon className="h-4 w-4 text-danger-500" />
          </button>
        </div>
        <button 
          onClick={() => onToggleStatus(flow.id)} 
          className={`button-${flow.status === 'ACTIVE' ? 'secondary' : 'primary'} text-sm flex items-center`}
        >
          {flow.status === 'ACTIVE' ? (
            <>
              <PauseIcon className="h-4 w-4 mr-1" />
              Pause
            </>
          ) : (
            <>
              <PlayIcon className="h-4 w-4 mr-1" />
              Activate
            </>
          )}
        </button>
      </div>
    </div>
  );
};

// Flow Builder Preview Component
const FlowBuilderPreview = () => {
  return (
    <div className="card-neumorphic h-96 flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium">Flow Builder</h3>
        <button className="button-primary text-sm">Open Editor</button>
      </div>
      
      <div className="flex-1 bg-secondary-50 rounded-xl p-4 flex items-center justify-center">
        <div className="text-center">
          <p className="text-secondary-500 mb-2">Visual flow builder preview</p>
          <p className="text-sm text-secondary-400">Create and edit conversation flows with our drag-and-drop builder</p>
        </div>
      </div>
    </div>
  );
};

// Flow Templates Component
const FlowTemplates = ({ onUseTemplate }) => {
  const templates = [
    { id: 1, name: 'Welcome Message', category: 'Onboarding', popularity: 'High' },
    { id: 2, name: 'Lead Generation', category: 'Marketing', popularity: 'High' },
    { id: 3, name: 'Customer Support', category: 'Support', popularity: 'Medium' },
    { id: 4, name: 'Appointment Booking', category: 'Services', popularity: 'Medium' },
  ];

  return (
    <div className="card-neumorphic">
      <h3 className="font-medium mb-4">Flow Templates</h3>
      <div className="space-y-3">
        {templates.map(template => (
          <div key={template.id} className="flex items-center justify-between p-3 bg-secondary-50 rounded-xl">
            <div>
              <p className="font-medium">{template.name}</p>
              <div className="flex items-center text-sm text-secondary-500">
                <span>{template.category}</span>
                <span className="mx-2">•</span>
                <span>Popularity: {template.popularity}</span>
              </div>
            </div>
            <button 
              onClick={() => onUseTemplate(template.id)} 
              className="button-secondary text-sm"
            >
              Use Template
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function Flows() {
  const [flows, setFlows] = useState([
    { 
      id: 1, 
      name: 'Welcome Flow', 
      description: 'Initial welcome message for new subscribers',
      status: 'ACTIVE',
      triggers: ['Keyword: start', 'New Subscriber'],
      createdAt: 'Apr 10, 2025',
      statistics: {
        started: 245,
        completed: 198
      }
    },
    { 
      id: 2, 
      name: 'Product Catalog', 
      description: 'Browse and purchase products',
      status: 'ACTIVE',
      triggers: ['Keyword: products', 'Button Click'],
      createdAt: 'Apr 12, 2025',
      statistics: {
        started: 187,
        completed: 132
      }
    },
    { 
      id: 3, 
      name: 'Feedback Survey', 
      description: 'Collect customer feedback',
      status: 'PAUSED',
      triggers: ['Keyword: feedback'],
      createdAt: 'Apr 15, 2025',
      statistics: {
        started: 56,
        completed: 43
      }
    },
    { 
      id: 4, 
      name: 'Abandoned Cart', 
      description: 'Follow up on abandoned carts',
      status: 'DRAFT',
      triggers: ['Event: cart_abandoned'],
      createdAt: 'Apr 18, 2025',
      statistics: {
        started: 0,
        completed: 0
      }
    }
  ]);
  
  const handleEditFlow = (flowId) => {
    // In a real app, this would navigate to the flow builder
    console.log(`Edit flow ${flowId}`);
  };
  
  const handleDuplicateFlow = (flowId) => {
    const flowToDuplicate = flows.find(flow => flow.id === flowId);
    const newFlow = {
      ...flowToDuplicate,
      id: flows.length + 1,
      name: `${flowToDuplicate.name} (Copy)`,
      status: 'DRAFT',
      createdAt: 'Today',
      statistics: {
        started: 0,
        completed: 0
      }
    };
    setFlows([...flows, newFlow]);
  };
  
  const handleDeleteFlow = (flowId) => {
    setFlows(flows.filter(flow => flow.id !== flowId));
  };
  
  const handleToggleStatus = (flowId) => {
    setFlows(flows.map(flow => {
      if (flow.id === flowId) {
        const newStatus = flow.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
        return { ...flow, status: newStatus };
      }
      return flow;
    }));
  };
  
  const handleUseTemplate = (templateId) => {
    // In a real app, this would create a new flow from the template
    const templateNames = {
      1: 'Welcome Message',
      2: 'Lead Generation',
      3: 'Customer Support',
      4: 'Appointment Booking'
    };
    
    const newFlow = {
      id: flows.length + 1,
      name: templateNames[templateId] || 'New Flow',
      description: 'Created from template',
      status: 'DRAFT',
      triggers: ['New Trigger'],
      createdAt: 'Today',
      statistics: {
        started: 0,
        completed: 0
      }
    };
    
    setFlows([...flows, newFlow]);
  };

  return (
    <Layout title="Flows" subtitle="Create and manage conversation flows">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">Flow Builder</h2>
          <p className="text-secondary-500">Create automated conversation flows</p>
        </div>
        <div className="flex space-x-3">
          <button className="button-secondary flex items-center">
            <ArrowPathIcon className="h-5 w-5 mr-2" />
            Import
          </button>
          <button className="button-primary flex items-center">
            <PlusIcon className="h-5 w-5 mr-2" />
            Create Flow
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <FlowBuilderPreview />
        </div>
        <div>
          <FlowTemplates onUseTemplate={handleUseTemplate} />
        </div>
      </div>
      
      <h3 className="text-lg font-semibold mb-4">Your Flows</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {flows.map(flow => (
          <FlowCard 
            key={flow.id} 
            flow={flow} 
            onEdit={handleEditFlow}
            onDuplicate={handleDuplicateFlow}
            onDelete={handleDeleteFlow}
            onToggleStatus={handleToggleStatus}
          />
        ))}
      </div>
    </Layout>
  );
}

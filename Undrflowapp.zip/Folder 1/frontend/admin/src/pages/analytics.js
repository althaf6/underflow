import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  ArrowTrendingUpIcon,
  CalendarIcon,
  ArrowDownTrayIcon,
  ChartBarIcon,
  ChartPieIcon,
  MapIcon
} from '@heroicons/react/24/outline';

// Analytics Card Component
const AnalyticsCard = ({ title, value, change, changeType, icon: Icon }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-secondary-500 font-medium">{title}</h3>
        <div className="h-10 w-10 rounded-xl bg-primary-50 flex items-center justify-center">
          <Icon className="h-6 w-6 text-primary-500" />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <p className="text-3xl font-bold">{value}</p>
        {change && (
          <p className={`flex items-center text-sm ${changeType === 'increase' ? 'text-success-500' : 'text-danger-500'}`}>
            <ArrowTrendingUpIcon className={`h-4 w-4 mr-1 ${changeType === 'decrease' && 'transform rotate-180'}`} />
            {change}
          </p>
        )}
      </div>
    </div>
  );
};

// Chart Component
const Chart = ({ title, type, height = 'h-64' }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium">{title}</h3>
        <div className="flex space-x-2">
          <button className="text-sm text-secondary-500 hover:text-secondary-700">Daily</button>
          <button className="text-sm text-primary-500 font-medium">Weekly</button>
          <button className="text-sm text-secondary-500 hover:text-secondary-700">Monthly</button>
        </div>
      </div>
      <div className={`${height} flex items-center justify-center bg-secondary-50 rounded-xl`}>
        <div className="text-center">
          <div className="flex justify-center mb-2">
            {type === 'bar' && <ChartBarIcon className="h-8 w-8 text-secondary-400" />}
            {type === 'pie' && <ChartPieIcon className="h-8 w-8 text-secondary-400" />}
            {type === 'map' && <MapIcon className="h-8 w-8 text-secondary-400" />}
          </div>
          <p className="text-secondary-500">{type.charAt(0).toUpperCase() + type.slice(1)} chart will be displayed here</p>
        </div>
      </div>
    </div>
  );
};

// Date Range Selector Component
const DateRangeSelector = ({ onDateChange }) => {
  const [dateRange, setDateRange] = useState('last7days');
  
  const handleChange = (e) => {
    setDateRange(e.target.value);
    onDateChange(e.target.value);
  };
  
  return (
    <div className="flex items-center space-x-3 mb-6">
      <div className="p-2 rounded-xl bg-white shadow-neumorphic">
        <CalendarIcon className="h-5 w-5 text-primary-500" />
      </div>
      <select
        value={dateRange}
        onChange={handleChange}
        className="input-neumorphic"
      >
        <option value="today">Today</option>
        <option value="yesterday">Yesterday</option>
        <option value="last7days">Last 7 Days</option>
        <option value="last30days">Last 30 Days</option>
        <option value="thisMonth">This Month</option>
        <option value="lastMonth">Last Month</option>
        <option value="custom">Custom Range</option>
      </select>
      <button className="button-secondary flex items-center">
        <ArrowDownTrayIcon className="h-5 w-5 mr-2" />
        Export
      </button>
    </div>
  );
};

export default function Analytics() {
  const [dateRange, setDateRange] = useState('last7days');
  
  const handleDateChange = (newDateRange) => {
    setDateRange(newDateRange);
    // In a real app, this would fetch new data based on the date range
  };

  return (
    <Layout title="Analytics" subtitle="Track your performance metrics">
      <DateRangeSelector onDateChange={handleDateChange} />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <AnalyticsCard 
          title="Total Messages" 
          value="45.2K" 
          change="12%" 
          changeType="increase" 
          icon={ChartBarIcon} 
        />
        <AnalyticsCard 
          title="Active Flows" 
          value="24" 
          change="8%" 
          changeType="increase" 
          icon={ArrowTrendingUpIcon} 
        />
        <AnalyticsCard 
          title="Conversion Rate" 
          value="24.8%" 
          change="3%" 
          changeType="decrease" 
          icon={ChartPieIcon} 
        />
        <AnalyticsCard 
          title="Avg. Response Time" 
          value="1.2m" 
          change="15%" 
          changeType="increase" 
          icon={CalendarIcon} 
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Chart title="Message Volume" type="bar" />
        <Chart title="Engagement by Channel" type="pie" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Chart title="Conversion Funnel" type="bar" height="h-80" />
        </div>
        <div>
          <Chart title="Geographic Distribution" type="map" height="h-80" />
        </div>
      </div>
    </Layout>
  );
}

import React, { useState } from 'react';
import Layout from '../components/Layout';
import { PlusIcon, ArrowPathIcon } from '@heroicons/react/24/outline';

// Channel Card Component
const ChannelCard = ({ channel, onConnect, onDisconnect }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'connected':
        return 'bg-success-500';
      case 'disconnected':
        return 'bg-secondary-400';
      case 'error':
        return 'bg-danger-500';
      default:
        return 'bg-warning-500';
    }
  };

  const getIcon = (type) => {
    switch (type) {
      case 'facebook':
        return '/facebook-icon.svg';
      case 'instagram':
        return '/instagram-icon.svg';
      case 'whatsapp':
        return '/whatsapp-icon.svg';
      default:
        return '/default-icon.svg';
    }
  };

  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="h-12 w-12 rounded-xl bg-white p-2 shadow-neumorphic flex items-center justify-center">
            <img src={getIcon(channel.type)} alt={channel.type} className="h-8 w-8" />
          </div>
          <div>
            <h3 className="font-medium">{channel.name}</h3>
            <div className="flex items-center space-x-2">
              <span className={`h-2 w-2 rounded-full ${getStatusColor(channel.status)}`}></span>
              <span className="text-sm text-secondary-500 capitalize">{channel.status}</span>
            </div>
          </div>
        </div>
        {channel.status === 'connected' ? (
          <button 
            onClick={() => onDisconnect(channel.id)} 
            className="button-secondary text-sm"
          >
            Disconnect
          </button>
        ) : (
          <button 
            onClick={() => onConnect(channel.type)} 
            className="button-primary text-sm"
          >
            Connect
          </button>
        )}
      </div>
      
      {channel.status === 'connected' && (
        <div className="bg-secondary-50 p-3 rounded-xl">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-secondary-500">Page:</span>
            <span className="font-medium">{channel.pageName}</span>
          </div>
          <div className="flex justify-between text-sm mb-2">
            <span className="text-secondary-500">Last Activity:</span>
            <span className="font-medium">{channel.lastActivity}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-secondary-500">Messages:</span>
            <span className="font-medium">{channel.messageCount}</span>
          </div>
        </div>
      )}
    </div>
  );
};

// Connection Modal Component
const ConnectionModal = ({ isOpen, onClose, channelType }) => {
  const [step, setStep] = useState(1);
  
  const getChannelName = (type) => {
    switch (type) {
      case 'facebook':
        return 'Facebook Messenger';
      case 'instagram':
        return 'Instagram Direct Messages';
      case 'whatsapp':
        return 'WhatsApp Business';
      default:
        return 'Channel';
    }
  };
  
  const getStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div>
            <p className="mb-4">To connect {getChannelName(channelType)}, you'll need to:</p>
            <ol className="list-decimal pl-5 space-y-2 mb-4">
              <li>Have a Facebook Developer account</li>
              <li>Create a Meta App in the Developer Portal</li>
              <li>Configure the necessary permissions</li>
            </ol>
            <p className="text-secondary-500 text-sm mb-4">
              Don't worry, we'll guide you through each step of the process.
            </p>
          </div>
        );
      case 2:
        return (
          <div>
            <p className="mb-4">Register your webhook URL in the Meta Developer Portal:</p>
            <div className="bg-secondary-50 p-3 rounded-xl mb-4">
              <code className="text-sm break-all">
                https://api.undrflow.com/webhooks/{channelType}/callback
              </code>
              <button className="text-primary-500 text-sm ml-2">
                Copy
              </button>
            </div>
            <p className="text-secondary-500 text-sm mb-4">
              This webhook will receive real-time updates when users message your page.
            </p>
          </div>
        );
      case 3:
        return (
          <div>
            <p className="mb-4">Click the button below to authenticate with Meta:</p>
            <div className="flex justify-center mb-4">
              <button className="button-primary">
                Authenticate with Meta
              </button>
            </div>
            <p className="text-secondary-500 text-sm mb-4">
              You'll be redirected to Meta to grant permissions to Undrflow.
            </p>
          </div>
        );
      default:
        return null;
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-md">
        <div className="p-6">
          <h2 className="text-xl font-bold mb-4">Connect {getChannelName(channelType)}</h2>
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex space-x-2">
                {[1, 2, 3].map((i) => (
                  <div 
                    key={i}
                    className={`h-2 w-2 rounded-full ${i <= step ? 'bg-primary-500' : 'bg-secondary-200'}`}
                  ></div>
                ))}
              </div>
              <span className="text-sm text-secondary-500">Step {step} of 3</span>
            </div>
            {getStepContent()}
          </div>
          <div className="flex justify-between">
            <button 
              onClick={step > 1 ? () => setStep(step - 1) : onClose}
              className="button-secondary"
            >
              {step > 1 ? 'Back' : 'Cancel'}
            </button>
            <button 
              onClick={step < 3 ? () => setStep(step + 1) : onClose}
              className="button-primary"
            >
              {step < 3 ? 'Next' : 'Finish'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function Channels() {
  const [channels, setChannels] = useState([
    { 
      id: 1, 
      type: 'facebook', 
      name: 'Facebook Messenger', 
      status: 'connected',
      pageName: 'My Business Page',
      lastActivity: '2 hours ago',
      messageCount: '1,234'
    },
    { 
      id: 2, 
      type: 'instagram', 
      name: 'Instagram Direct', 
      status: 'disconnected' 
    },
    { 
      id: 3, 
      type: 'whatsapp', 
      name: 'WhatsApp Business', 
      status: 'disconnected' 
    }
  ]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedChannelType, setSelectedChannelType] = useState(null);
  
  const handleConnect = (channelType) => {
    setSelectedChannelType(channelType);
    setIsModalOpen(true);
  };
  
  const handleDisconnect = (channelId) => {
    // In a real app, this would call an API to disconnect the channel
    setChannels(channels.map(channel => 
      channel.id === channelId 
        ? { ...channel, status: 'disconnected' } 
        : channel
    ));
  };

  return (
    <Layout title="Channels" subtitle="Connect and manage your messaging platforms">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">Connected Platforms</h2>
          <p className="text-secondary-500">Manage your messaging channel integrations</p>
        </div>
        <button className="button-primary flex items-center">
          <PlusIcon className="h-5 w-5 mr-2" />
          Add Custom Channel
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {channels.map(channel => (
          <ChannelCard 
            key={channel.id} 
            channel={channel} 
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
          />
        ))}
      </div>
      
      <div className="card-neumorphic">
        <h3 className="font-medium mb-4">Webhook Status</h3>
        <div className="bg-secondary-50 p-4 rounded-xl mb-4">
          <div className="flex justify-between mb-2">
            <span className="text-secondary-500">Webhook URL:</span>
            <div className="flex items-center">
              <code className="text-sm">https://api.undrflow.com/webhooks/callback</code>
              <button className="text-primary-500 text-sm ml-2">
                Copy
              </button>
            </div>
          </div>
          <div className="flex justify-between">
            <span className="text-secondary-500">Status:</span>
            <div className="flex items-center">
              <span className="h-2 w-2 rounded-full bg-success-500 mr-2"></span>
              <span>Active</span>
            </div>
          </div>
        </div>
        <button className="button-secondary flex items-center mx-auto">
          <ArrowPathIcon className="h-5 w-5 mr-2" />
          Test Webhook
        </button>
      </div>
      
      <ConnectionModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        channelType={selectedChannelType}
      />
    </Layout>
  );
}

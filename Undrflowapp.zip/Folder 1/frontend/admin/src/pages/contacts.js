import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  PencilIcon, 
  TrashIcon, 
  PlusIcon,
  FunnelIcon,
  TagIcon,
  MagnifyingGlassIcon
} from '@heroicons/react/24/outline';

// Contact Card Component
const ContactCard = ({ contact, onEdit, onDelete }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center space-x-4">
        <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center">
          <span className="text-primary-700 font-medium">
            {contact.firstName.charAt(0)}{contact.lastName.charAt(0)}
          </span>
        </div>
        <div className="flex-1">
          <h3 className="font-medium">{contact.firstName} {contact.lastName}</h3>
          <div className="flex items-center text-sm text-secondary-500">
            <span>{contact.email}</span>
            {contact.phone && (
              <>
                <span className="mx-2">•</span>
                <span>{contact.phone}</span>
              </>
            )}
          </div>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={() => onEdit(contact.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
          >
            <PencilIcon className="h-4 w-4 text-secondary-500" />
          </button>
          <button 
            onClick={() => onDelete(contact.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
          >
            <TrashIcon className="h-4 w-4 text-danger-500" />
          </button>
        </div>
      </div>
      
      {contact.tags && contact.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-2">
          {contact.tags.map((tag, index) => (
            <span 
              key={index} 
              className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
            >
              {tag}
            </span>
          ))}
        </div>
      )}
      
      <div className="mt-4 pt-4 border-t border-secondary-100 grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-xs text-secondary-500">Source</p>
          <p className="text-sm font-medium">{contact.source}</p>
        </div>
        <div>
          <p className="text-xs text-secondary-500">Status</p>
          <div className="flex items-center justify-center">
            <span className={`h-2 w-2 rounded-full mr-1 ${
              contact.status === 'Active' ? 'bg-success-500' :
              contact.status === 'Unsubscribed' ? 'bg-secondary-400' : 'bg-danger-500'
            }`}></span>
            <p className="text-sm font-medium">{contact.status}</p>
          </div>
        </div>
        <div>
          <p className="text-xs text-secondary-500">Last Activity</p>
          <p className="text-sm font-medium">{contact.lastActivity}</p>
        </div>
      </div>
    </div>
  );
};

// Contact Modal Component
const ContactModal = ({ isOpen, onClose, contact, isEditing }) => {
  const [formData, setFormData] = useState(
    contact || {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      source: 'Manual',
      status: 'Active',
      tags: []
    }
  );
  
  const [tagInput, setTagInput] = useState('');
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAddTag = () => {
    if (tagInput.trim() !== '') {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim()]
      }));
      setTagInput('');
    }
  };
  
  const handleRemoveTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real app, this would call an API to create/update the contact
    onClose(formData);
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-md">
        <form onSubmit={handleSubmit} className="p-6">
          <h2 className="text-xl font-bold mb-4">
            {isEditing ? 'Edit Contact' : 'Add New Contact'}
          </h2>
          
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  First Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="input-neumorphic w-full"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  Last Name
                </label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="input-neumorphic w-full"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="input-neumorphic w-full"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Phone
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="input-neumorphic w-full"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Source
              </label>
              <select
                name="source"
                value={formData.source}
                onChange={handleChange}
                className="input-neumorphic w-full"
              >
                <option value="Manual">Manual</option>
                <option value="Facebook">Facebook</option>
                <option value="Instagram">Instagram</option>
                <option value="WhatsApp">WhatsApp</option>
                <option value="Import">Import</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="input-neumorphic w-full"
              >
                <option value="Active">Active</option>
                <option value="Unsubscribed">Unsubscribed</option>
                <option value="Bounced">Bounced</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Tags
              </label>
              <div className="flex space-x-2 mb-2">
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  className="input-neumorphic flex-1"
                  placeholder="Add a tag"
                />
                <button
                  type="button"
                  onClick={handleAddTag}
                  className="button-secondary"
                >
                  Add
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, index) => (
                  <span 
                    key={index} 
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-1 text-primary-500 hover:text-primary-700"
                    >
                      &times;
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex justify-between">
            <button 
              type="button"
              onClick={() => onClose(null)}
              className="button-secondary"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="button-primary"
            >
              {isEditing ? 'Update Contact' : 'Add Contact'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default function Contacts() {
  const [contacts, setContacts] = useState([
    { 
      id: 1, 
      firstName: 'Alice', 
      lastName: 'Johnson', 
      email: 'alice.johnson@example.com',
      phone: '+1 (555) 123-4567',
      source: 'Facebook',
      status: 'Active',
      lastActivity: '2 hours ago',
      tags: ['Customer', 'VIP']
    },
    { 
      id: 2, 
      firstName: 'Bob', 
      lastName: 'Smith', 
      email: 'bob.smith@example.com',
      phone: '+1 (555) 987-6543',
      source: 'WhatsApp',
      status: 'Active',
      lastActivity: '1 day ago',
      tags: ['Lead']
    },
    { 
      id: 3, 
      firstName: 'Carol', 
      lastName: 'Williams', 
      email: 'carol.williams@example.com',
      phone: '',
      source: 'Instagram',
      status: 'Unsubscribed',
      lastActivity: '1 week ago',
      tags: []
    },
    { 
      id: 4, 
      firstName: 'David', 
      lastName: 'Brown', 
      email: 'david.brown@example.com',
      phone: '+1 (555) 456-7890',
      source: 'Manual',
      status: 'Active',
      lastActivity: '3 days ago',
      tags: ['Customer', 'Newsletter']
    }
  ]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentContact, setCurrentContact] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  
  const handleAddContact = () => {
    setCurrentContact(null);
    setIsEditing(false);
    setIsModalOpen(true);
  };
  
  const handleEditContact = (contactId) => {
    const contact = contacts.find(c => c.id === contactId);
    setCurrentContact(contact);
    setIsEditing(true);
    setIsModalOpen(true);
  };
  
  const handleDeleteContact = (contactId) => {
    // In a real app, this would call an API to delete the contact
    setContacts(contacts.filter(contact => contact.id !== contactId));
  };
  
  const handleModalClose = (contactData) => {
    if (contactData) {
      if (isEditing) {
        // Update existing contact
        setContacts(contacts.map(contact => 
          contact.id === currentContact.id ? { ...contact, ...contactData } : contact
        ));
      } else {
        // Add new contact
        setContacts([...contacts, { ...contactData, id: contacts.length + 1, lastActivity: 'Just now' }]);
      }
    }
    setIsModalOpen(false);
  };

  return (
    <Layout title="Contacts" subtitle="Manage your audience">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">Contact Management</h2>
          <p className="text-secondary-500">Total contacts: {contacts.length}</p>
        </div>
        <div className="flex space-x-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <MagnifyingGlassIcon className="h-5 w-5 text-secondary-400" />
            </div>
            <input
              type="text"
              className="input-neumorphic pl-10 pr-4 py-2 w-64"
              placeholder="Search contacts..."
            />
          </div>
          <button className="button-secondary flex items-center">
            <TagIcon className="h-5 w-5 mr-2" />
            Tags
          </button>
          <button className="button-secondary flex items-center">
            <FunnelIcon className="h-5 w-5 mr-2" />
            Filter
          </button>
          <button 
            onClick={handleAddContact}
            className="button-primary flex items-center"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Add Contact
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {contacts.map(contact => (
          <ContactCard 
            key={contact.id} 
            contact={contact} 
            onEdit={handleEditContact}
            onDelete={handleDeleteContact}
          />
        ))}
      </div>
      
      <ContactModal 
        isOpen={isModalOpen} 
        onClose={handleModalClose} 
        contact={currentContact}
        isEditing={isEditing}
      />
    </Layout>
  );
}

import React from 'react';
import { 
  ArrowTrendingUpIcon, 
  UserGroupIcon, 
  ChatBubbleLeftRightIcon,
  EnvelopeIcon
} from '@heroicons/react/24/outline';
import Layout from '../components/Layout';

// Stat Card Component
const StatCard = ({ title, value, icon: Icon, change, changeType }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-secondary-500 font-medium">{title}</h3>
        <div className="h-10 w-10 rounded-xl bg-primary-50 flex items-center justify-center">
          <Icon className="h-6 w-6 text-primary-500" />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <p className="text-3xl font-bold">{value}</p>
        {change && (
          <p className={`flex items-center text-sm ${changeType === 'increase' ? 'text-success-500' : 'text-danger-500'}`}>
            <ArrowTrendingUpIcon className={`h-4 w-4 mr-1 ${changeType === 'decrease' && 'transform rotate-180'}`} />
            {change}
          </p>
        )}
      </div>
    </div>
  );
};

// Chart Card Component
const ChartCard = ({ title, children }) => {
  return (
    <div className="card-neumorphic">
      <h3 className="text-secondary-500 font-medium mb-4">{title}</h3>
      <div className="h-64">
        {children}
      </div>
    </div>
  );
};

// Recent Activity Component
const RecentActivity = () => {
  const activities = [
    { id: 1, type: 'contact', message: 'New contact joined', time: '2 min ago' },
    { id: 2, type: 'message', message: 'New message received', time: '15 min ago' },
    { id: 3, type: 'flow', message: 'Flow "Welcome" completed', time: '1 hour ago' },
    { id: 4, type: 'subscription', message: 'New Pro subscription', time: '3 hours ago' },
  ];

  const getIcon = (type) => {
    switch (type) {
      case 'contact':
        return <UserGroupIcon className="h-5 w-5 text-primary-500" />;
      case 'message':
        return <EnvelopeIcon className="h-5 w-5 text-success-500" />;
      case 'flow':
        return <ChatBubbleLeftRightIcon className="h-5 w-5 text-warning-500" />;
      default:
        return <ArrowTrendingUpIcon className="h-5 w-5 text-secondary-500" />;
    }
  };

  return (
    <div className="card-neumorphic">
      <h3 className="text-secondary-500 font-medium mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-center space-x-3 p-3 rounded-xl bg-secondary-50">
            <div className="h-8 w-8 rounded-full bg-white flex items-center justify-center">
              {getIcon(activity.type)}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{activity.message}</p>
              <p className="text-xs text-secondary-400">{activity.time}</p>
            </div>
          </div>
        ))}
      </div>
      <button className="w-full mt-4 button-secondary">View All Activity</button>
    </div>
  );
};

export default function Dashboard() {
  return (
    <Layout title="Dashboard" subtitle="Welcome back, John!">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatCard 
          title="Total Users" 
          value="1,234" 
          icon={UserGroupIcon} 
          change="12%" 
          changeType="increase" 
        />
        <StatCard 
          title="Active Contacts" 
          value="5,678" 
          icon={UserGroupIcon} 
          change="8%" 
          changeType="increase" 
        />
        <StatCard 
          title="Messages Sent" 
          value="45.2K" 
          icon={EnvelopeIcon} 
          change="5%" 
          changeType="increase" 
        />
        <StatCard 
          title="Conversion Rate" 
          value="24.8%" 
          icon={ArrowTrendingUpIcon} 
          change="3%" 
          changeType="decrease" 
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ChartCard title="User Growth">
            <div className="flex items-center justify-center h-full text-secondary-400">
              Chart will be displayed here
            </div>
          </ChartCard>
        </div>
        <div>
          <RecentActivity />
        </div>
      </div>
    </Layout>
  );
}

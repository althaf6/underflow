import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  PencilIcon, 
  TrashIcon, 
  PlusIcon,
  FunnelIcon,
  ArrowsUpDownIcon
} from '@heroicons/react/24/outline';

// User Card Component
const UserCard = ({ user, onEdit, onDelete }) => {
  return (
    <div className="card-neumorphic">
      <div className="flex items-center space-x-4">
        <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center">
          <span className="text-primary-700 font-medium">
            {user.firstName.charAt(0)}{user.lastName.charAt(0)}
          </span>
        </div>
        <div className="flex-1">
          <h3 className="font-medium">{user.firstName} {user.lastName}</h3>
          <p className="text-sm text-secondary-500">{user.email}</p>
        </div>
        <div className="flex space-x-2">
          <button 
            onClick={() => onEdit(user.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
          >
            <PencilIcon className="h-4 w-4 text-secondary-500" />
          </button>
          <button 
            onClick={() => onDelete(user.id)} 
            className="p-2 rounded-full bg-white shadow-neumorphic"
          >
            <TrashIcon className="h-4 w-4 text-danger-500" />
          </button>
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-secondary-100 grid grid-cols-3 gap-4 text-center">
        <div>
          <p className="text-xs text-secondary-500">Subscription</p>
          <p className={`text-sm font-medium ${
            user.subscription === 'Free' ? 'text-secondary-500' :
            user.subscription === 'Pro' ? 'text-primary-500' :
            user.subscription === 'Premium' ? 'text-warning-500' : 'text-success-500'
          }`}>
            {user.subscription}
          </p>
        </div>
        <div>
          <p className="text-xs text-secondary-500">Status</p>
          <div className="flex items-center justify-center">
            <span className={`h-2 w-2 rounded-full mr-1 ${
              user.status === 'Active' ? 'bg-success-500' :
              user.status === 'Inactive' ? 'bg-secondary-400' : 'bg-danger-500'
            }`}></span>
            <p className="text-sm font-medium">{user.status}</p>
          </div>
        </div>
        <div>
          <p className="text-xs text-secondary-500">Joined</p>
          <p className="text-sm font-medium">{user.joinedDate}</p>
        </div>
      </div>
    </div>
  );
};

// User Modal Component
const UserModal = ({ isOpen, onClose, user, isEditing }) => {
  const [formData, setFormData] = useState(
    user || {
      firstName: '',
      lastName: '',
      email: '',
      role: 'USER',
      subscription: 'Free',
      status: 'Active'
    }
  );
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real app, this would call an API to create/update the user
    onClose(formData);
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl shadow-lg w-full max-w-md">
        <form onSubmit={handleSubmit} className="p-6">
          <h2 className="text-xl font-bold mb-4">
            {isEditing ? 'Edit User' : 'Add New User'}
          </h2>
          
          <div className="space-y-4 mb-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  First Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="input-neumorphic w-full"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-1">
                  Last Name
                </label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="input-neumorphic w-full"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="input-neumorphic w-full"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Role
              </label>
              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
                className="input-neumorphic w-full"
              >
                <option value="USER">User</option>
                <option value="ADMIN">Admin</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Subscription
              </label>
              <select
                name="subscription"
                value={formData.subscription}
                onChange={handleChange}
                className="input-neumorphic w-full"
              >
                <option value="Free">Free</option>
                <option value="Pro">Pro</option>
                <option value="Premium">Premium</option>
                <option value="Enterprise">Enterprise</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Status
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="input-neumorphic w-full"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Suspended">Suspended</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-between">
            <button 
              type="button"
              onClick={() => onClose(null)}
              className="button-secondary"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="button-primary"
            >
              {isEditing ? 'Update User' : 'Add User'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default function Users() {
  const [users, setUsers] = useState([
    { 
      id: 1, 
      firstName: 'John', 
      lastName: 'Doe', 
      email: 'john.doe@example.com',
      role: 'ADMIN',
      subscription: 'Premium',
      status: 'Active',
      joinedDate: 'Jan 15, 2025'
    },
    { 
      id: 2, 
      firstName: 'Jane', 
      lastName: 'Smith', 
      email: 'jane.smith@example.com',
      role: 'USER',
      subscription: 'Pro',
      status: 'Active',
      joinedDate: 'Feb 20, 2025'
    },
    { 
      id: 3, 
      firstName: 'Robert', 
      lastName: 'Johnson', 
      email: 'robert.johnson@example.com',
      role: 'USER',
      subscription: 'Free',
      status: 'Inactive',
      joinedDate: 'Mar 5, 2025'
    },
    { 
      id: 4, 
      firstName: 'Emily', 
      lastName: 'Williams', 
      email: 'emily.williams@example.com',
      role: 'USER',
      subscription: 'Enterprise',
      status: 'Active',
      joinedDate: 'Mar 12, 2025'
    }
  ]);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  
  const handleAddUser = () => {
    setCurrentUser(null);
    setIsEditing(false);
    setIsModalOpen(true);
  };
  
  const handleEditUser = (userId) => {
    const user = users.find(u => u.id === userId);
    setCurrentUser(user);
    setIsEditing(true);
    setIsModalOpen(true);
  };
  
  const handleDeleteUser = (userId) => {
    // In a real app, this would call an API to delete the user
    setUsers(users.filter(user => user.id !== userId));
  };
  
  const handleModalClose = (userData) => {
    if (userData) {
      if (isEditing) {
        // Update existing user
        setUsers(users.map(user => 
          user.id === currentUser.id ? { ...user, ...userData } : user
        ));
      } else {
        // Add new user
        setUsers([...users, { ...userData, id: users.length + 1, joinedDate: 'Today' }]);
      }
    }
    setIsModalOpen(false);
  };

  return (
    <Layout title="Users" subtitle="Manage your platform users">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-bold">User Management</h2>
          <p className="text-secondary-500">Total users: {users.length}</p>
        </div>
        <div className="flex space-x-3">
          <button className="button-secondary flex items-center">
            <FunnelIcon className="h-5 w-5 mr-2" />
            Filter
          </button>
          <button className="button-secondary flex items-center">
            <ArrowsUpDownIcon className="h-5 w-5 mr-2" />
            Sort
          </button>
          <button 
            onClick={handleAddUser}
            className="button-primary flex items-center"
          >
            <PlusIcon className="h-5 w-5 mr-2" />
            Add User
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map(user => (
          <UserCard 
            key={user.id} 
            user={user} 
            onEdit={handleEditUser}
            onDelete={handleDeleteUser}
          />
        ))}
      </div>
      
      <UserModal 
        isOpen={isModalOpen} 
        onClose={handleModalClose} 
        user={currentUser}
        isEditing={isEditing}
      />
    </Layout>
  );
}

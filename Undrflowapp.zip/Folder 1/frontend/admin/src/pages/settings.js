import React, { useState } from 'react';
import Layout from '../components/Layout';
import { 
  Cog6ToothIcon,
  UserIcon,
  BellIcon,
  LockClosedIcon,
  CreditCardIcon,
  GlobeAltIcon,
  DocumentTextIcon,
  ArrowPathIcon
} from '@heroicons/react/24/outline';

// Settings Tab Component
const SettingsTab = ({ icon: Icon, title, active, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-3 w-full text-left px-4 py-3 rounded-xl transition-all duration-300 ${
        active ? 'bg-primary-50 text-primary-700' : 'hover:bg-secondary-100'
      }`}
    >
      <Icon className="h-5 w-5" />
      <span>{title}</span>
    </button>
  );
};

// Profile Settings Component
const ProfileSettings = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Profile Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <div className="flex items-center space-x-4 mb-6">
          <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center">
            <span className="text-primary-700 text-xl font-medium">JD</span>
          </div>
          <div>
            <h3 className="font-medium">John Doe</h3>
            <p className="text-sm text-secondary-500">john.doe@example.com</p>
          </div>
          <button className="button-secondary ml-auto">Change Avatar</button>
        </div>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                First Name
              </label>
              <input
                type="text"
                defaultValue="John"
                className="input-neumorphic w-full"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-1">
                Last Name
              </label>
              <input
                type="text"
                defaultValue="Doe"
                className="input-neumorphic w-full"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Email
            </label>
            <input
              type="email"
              defaultValue="john.doe@example.com"
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Phone
            </label>
            <input
              type="tel"
              defaultValue="+1 (555) 123-4567"
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Company
            </label>
            <input
              type="text"
              defaultValue="Acme Inc."
              className="input-neumorphic w-full"
            />
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="button-primary">Save Changes</button>
      </div>
    </div>
  );
};

// Security Settings Component
const SecuritySettings = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Security Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Change Password</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Current Password
            </label>
            <input
              type="password"
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              New Password
            </label>
            <input
              type="password"
              className="input-neumorphic w-full"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-1">
              Confirm New Password
            </label>
            <input
              type="password"
              className="input-neumorphic w-full"
            />
          </div>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Two-Factor Authentication</h3>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-secondary-700">Protect your account with 2FA</p>
            <p className="text-sm text-secondary-500">Currently disabled</p>
          </div>
          <button className="button-primary">Enable 2FA</button>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">API Keys</h3>
        <div className="bg-secondary-50 p-3 rounded-xl mb-4">
          <div className="flex justify-between mb-2">
            <span className="text-secondary-500">Active API Key:</span>
            <div className="flex items-center">
              <code className="text-sm">••••••••••••••••••••••••</code>
              <button className="text-primary-500 text-sm ml-2">
                Show
              </button>
            </div>
          </div>
          <div className="flex justify-between">
            <span className="text-secondary-500">Created:</span>
            <span>Mar 15, 2025</span>
          </div>
        </div>
        <div className="flex justify-end">
          <button className="button-secondary flex items-center">
            <ArrowPathIcon className="h-5 w-5 mr-2" />
            Regenerate Key
          </button>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="button-primary">Save Changes</button>
      </div>
    </div>
  );
};

// Notification Settings Component
const NotificationSettings = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Notification Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Email Notifications</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">New Contact Notifications</p>
              <p className="text-sm text-secondary-500">Get notified when a new contact is added</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Flow Completion Alerts</p>
              <p className="text-sm text-secondary-500">Get notified when a flow is completed</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Subscription Updates</p>
              <p className="text-sm text-secondary-500">Get notified about subscription changes</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Marketing Updates</p>
              <p className="text-sm text-secondary-500">Receive marketing and feature updates</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">In-App Notifications</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Real-time Alerts</p>
              <p className="text-sm text-secondary-500">Show real-time notifications in the dashboard</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" defaultChecked />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-secondary-700">Sound Alerts</p>
              <p className="text-sm text-secondary-500">Play sound when notifications arrive</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-secondary-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-secondary-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-500"></div>
            </label>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="button-primary">Save Changes</button>
      </div>
    </div>
  );
};

// Billing Settings Component
const BillingSettings = () => {
  return (
    <div>
      <h2 className="text-xl font-bold mb-6">Billing Settings</h2>
      
      <div className="card-neumorphic mb-6">
        <h3 className="font-medium mb-4">Current Plan</h3>
        <div className="bg-primary-50 p-4 rounded-xl mb-4">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-lg font-bold text-primary-700">Premium Plan</span>
              <span className="ml-2 px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800">
                Active
              </span>
            </div>
            <span className="text-xl font-bold">$49<span className="text-sm font-normal">/month</span></span>
          </div>
          <p className="text-sm text-secondary-600 mb-2">
            Your plan renews on May 21, 2025
          </p>
          <div className="flex space-x-3">
            <button className="button-secondary text-sm">Change Plan</button>
            <button className="text-sm text-danger-500 hover:text-danger-700">Cancel Subscription</button>
          </div>
        </div>
        
        <h3 className="font-medium mb-4">Payment Method</h3>
        <div className="bg-secondary-50 p-4 rounded-xl mb-4">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-lg bg-white p-2 shadow-neumorphic flex items-center justify-center">
              <CreditCardIcon className="h-6 w-6 text-secondary-700" />
            </div>
            <div>
              <p className="font-medium">Visa ending in 4242</p>
              <p className="text-sm text-secondary-500">Expires 12/2026</p>
            </div>
            <button className="button-secondary text-sm ml-auto">Update</button>
          </div>
        </div>
        
        <h3 className="font-medium mb-4">Billing History</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-secondary-100">
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Date</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Description</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Amount</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Status</th>
                <th className="text-left py-3 px-4 text-sm font-medium text-secondary-500">Invoice</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-secondary-100">
                <td className="py-3 px-4 text-sm">Apr 21, 2025</td>
                <td className="py-3 px-4 text-sm">Premium Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$49.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </tr>
              <tr className="border-b border-secondary-100">
                <td className="py-3 px-4 text-sm">Mar 21, 2025</td>
                <td className="py-3 px-4 text-sm">Premium Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$49.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-sm">Feb 21, 2025</td>
                <td className="py-3 px-4 text-sm">Premium Plan - Monthly</td>
                <td className="py-3 px-4 text-sm">$49.00</td>
                <td className="py-3 px-4 text-sm">
                  <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-success-100 text-success-800">
                    Paid
                  </span>
                </td>
                <td className="py-3 px-4 text-sm">
                  <a href="#" className="text-primary-500 hover:text-primary-700">Download</a>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfileSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'notifications':
        return <NotificationSettings />;
      case 'billing':
        return <BillingSettings />;
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <Layout title="Settings" subtitle="Manage your account settings">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-64 space-y-2">
          <SettingsTab 
            icon={UserIcon} 
            title="Profile" 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')} 
          />
          <SettingsTab 
            icon={LockClosedIcon} 
            title="Security" 
            active={activeTab === 'security'} 
            onClick={() => setActiveTab('security')} 
          />
          <SettingsTab 
            icon={BellIcon} 
            title="Notifications" 
            active={activeTab === 'notifications'} 
            onClick={() => setActiveTab('notifications')} 
          />
          <SettingsTab 
            icon={CreditCardIcon} 
            title="Billing" 
            active={activeTab === 'billing'} 
            onClick={() => setActiveTab('billing')} 
          />
          <SettingsTab 
            icon={GlobeAltIcon} 
            title="Integrations" 
            active={activeTab === 'integrations'} 
            onClick={() => setActiveTab('integrations')} 
          />
          <SettingsTab 
            icon={DocumentTextIcon} 
            title="Legal" 
            active={activeTab === 'legal'} 
            onClick={() => setActiveTab('legal')} 
          />
        </div>
        <div className="flex-1">
          {renderTabContent()}
        </div>
      </div>
    </Layout>
  );
}
